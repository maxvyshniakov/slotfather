#!/usr/bin/env python3
"""slotfather: one queue of leases on the machine's capacity, shared by every project and agent (#599).

  slotfather run [-n N|all] [--label L] [--meta K=V]... [--class C] [--yieldable] [--wait S] [--] COMMAND...
                                                                     run COMMAND holding N slots (default 1)
  slotfather yield                                                   inside a yieldable lease: yield if asked
  slotfather status [--json [--pid PID]]                             holders and waiters, in queue order
  slotfather history [N]                                             the last N requests that left the queue
  slotfather stats [--since W] [--label L] [--by B] [--json]         what leases used and how full the machine was
  slotfather slots [N|memory G|lower G|reset]                        show, save or reset shared capacity
  slotfather available [--label L] [-- COMMAND...]                   slots a new request gets at once
  slotfather advise [--max N] [--exclusive] [--label L] [-- CMD...]  a job count for the load, as JSON
  slotfather order [backfill|window] [--safety X] [--limit S] ...    show, save or reset the queue's order
  slotfather sweep [--live [--dev-servers]] [--json] | config | --plist  find (and stop) processes left behind
  slotfather [dashboard [--interval S | --once]]                     live view of capacity, leases and queue

Run heavy builds and tests through `slotfather run -n <k> -- ...`: a test suite or build that keeps the
machine busy takes 1 to 2 slots, a full gate that must not share the machine takes `-n all`.

Slots: one per three cores, at least one, and no more than one per 4 GiB of memory, so
`total = min(max(1, cores // 3), max(1, memory_GiB // 4))`: 4 on a 12-core M2 Max with 32 GiB, 2 on a 6-core VM with
12 GiB (on Linux the memory is the limit of the queue's cgroup where it has one: SLOTFATHER_CGROUP, the one
install.py --cgroup wrote in, the one saved with the capacity, or the caller's outermost limited one). A request
above a capacity that shrank takes every slot at its grant, and -n all the capacity then. `slotfather slots N` saves shared capacity; `slots memory G` one slot per G GiB of memory, `slots lower G` the
lower of that and the CPU budget (#653); `slotfather slots reset` restores the automatic default. SLOTFATHER_CORES
replaces the core count, SLOTFATHER_MEMORY_GIB the memory. A request above the total takes every slot.

Requests are served in arrival order. A waiter that does not fit lets later requests that fit start before it until
it has waited SLOTFATHER_OVERTAKE_WINDOW seconds (default 600). Past that it is the head (#643, the backfill order):
a later request that fits still starts first if, by the run times of earlier requests of its kind in the history,
three times its expected run ends before the head can start (when the held leases are expected to end) and before
the head has waited 2700 s, its limit; past the limit nothing passes it. An all-slot request therefore starts at
most the limit plus the overrun of what passed it, or, with classes, once what ranks ahead of it has run: the
requests that came within the class offsets after it (up to 3600 s for a batch one), and their overrun. `slotfather order` shows and saves the order and these numbers
for every client (order.json beside the queue); a client's environment can only tighten them, and
SLOTFATHER_QUEUE=window falls back to the earlier order, where the head holds back everyone behind it. Classes
(`--class interactive|normal|batch`, normal by default): an interactive waiter queues as if it came 1800 s earlier,
a batch one 1800 s later; an interactive waiter that has waited 120 s asks holders of a lower class that took
`--yieldable` to yield, by a marker file their client checks between steps (SLOTFATHER_YIELD) before it runs
`slotfather yield`; nothing ever stops a holder. A process
that already runs under a lease (SLOTFATHER_LEASE, or a holder among its ancestors) runs without a second lease, so
nested wrappers neither deadlock nor count twice. A lease whose holder died (its pid gone, or reused by a process
with another start time) is reaped by the next queue operation. While memory is short (free swap under SLOTFATHER_MIN_FREE_SWAP_MB, default 512, where swap is on; on
macOS the kernel's memory-pressure level at warning or above; on Linux MemAvailable under SLOTFATHER_MIN_AVAILABLE_MB,
default 1024, or the queue's cgroup's memory.max less its working set under that, or PSI memory avg10, the cgroup's
or else the machine's, at SLOTFATHER_MAX_PSI_SOME percent, default 10, or _FULL, default 5), new leases
wait for running ones; with nothing running they start. A waiter checks its own entry every SLOTFATHER_POLL seconds (default 2) but looks over the queue, which runs
ps, less often the longer nothing changes, up to SLOTFATHER_POLL_MAX (default 10); a release hands its slots on at
once. `--wait S` gives up after S seconds with exit 75 and leaves the queue. `run` exits with the command's status
(128 + the signal when a signal ended it).

`advise` sizes work for processes that take no lease: with each slot `cores / total` cores, the current load,
min(load1, load5), less what the held slots account for, max(0, load - held x cores per slot), is load without a
lease. Not load15: it still holds work whose leases ended minutes ago, and min() ignores a one-minute spike.
The job count is the slots left after that load (and after the held slots, unless --exclusive: an all-slot
request waits for them), a slot counting while at least half its cores are idle, never above --max (default
the total) nor, without --exclusive, the free slots, and at least 1. SLOTFATHER_LOADAVG replaces the load
averages: "load1 load5 load15", or one number for all three.

State: ~/.local/state/slotfather (SLOTFATHER_DIR replaces it; another user's queue is read only: changes are
refused and reading creates nothing; queue.log records grants, releases and
reaps; history.jsonl, which `history` lists, has a line per request that left the queue: its command, directory,
wait, run and outcome, and for `run` what its process tree used; machine.jsonl samples the machine while leases
run; `stats` reads both). While its command runs, the holder looks at the command's process tree every
SLOTFATHER_SAMPLE_MAX seconds at most (default 10; the first look comes sooner): CPU time is the command's own
rusage, which holds every descendant reaped inside the tree, plus the sampled CPU of processes that left the tree
(orphans, and launchd children carrying the lease's SLOTFATHER_LEASE). Held leases in the queues listed in
SLOTFATHER_LEGACY_DIRS (colon-separated; default Straylight's earlier ~/.local/state/straylight-verification/slots;
empty to ignore) count as used, scaled from their 4 slots, until their holders exit. SLOTFATHER_POLICY: normal
(default), background (low QoS), or bypass (no lease; for a person who knows the machine is idle). Standard library
only, Python 3.9 or later: install.py puts it, slotfather-dashboard and slotfather-stats, which `slotfather
dashboard` and `slotfather stats` run from beside it, in ~/.local/bin.
"""
from __future__ import annotations

import contextlib
import datetime
import fcntl
import json
import math
import os
from pathlib import Path
import pwd
import re
import signal
import stat
import subprocess
import sys
import threading
import time

MIN_PYTHON = (3, 9)
if sys.version_info < MIN_PYTHON:
    sys.exit(f"slotfather needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or later, not {sys.version.split()[0]} at "
             f"{sys.executable}; reinstall with a newer one: /path/to/python3 install.py")

DEFAULT_DIR = "~/.local/state/slotfather"
DEFAULT_CGROUP = None  # install.py --cgroup writes the queue's cgroup here, so every client of the queue names it
DEFAULT_LEGACY_DIRS = "~/.local/state/straylight-verification/slots"
LEGACY_TOTAL = 4  # the earlier queue's fixed slot count
CORES_PER_SLOT = 3
# Capacity by memory (#653): `slotfather slots memory G` gives one slot per G GiB of the machine's memory (rounded to
# whole GiB), `slots lower G` the lower of that and the CPU budget. The automatic capacity is the lower of the CPU
# budget and one slot per AUTO_GIB_PER_SLOT: heavy leases on the 12-core Mac peaked at 2 to 3 GiB of summed resident
# memory per slot in the median, 6 GiB at most (#635's history, 2026-11-03).
AUTO_GIB_PER_SLOT = 4.0
CAPACITY_MODES = ("memory", "lower")  # saved in capacity.json beside "slots", which older clients read alone
MIN_FREE_SWAP_MB = 512
MAX_PRESSURE_LEVEL = 1  # kern.memorystatus_vm_pressure_level: 1 normal, 2 warning, 4 critical
# Linux (#653): new leases wait while MemAvailable is under this many MB, or while PSI (/proc/pressure/memory) says
# tasks stalled on memory for at least this share of the last 10 s: some (at least one task) or full (all of them).
MIN_AVAILABLE_MB = 1024
MAX_PSI_SOME = 10.0
MAX_PSI_FULL = 5.0
POLICIES = ("normal", "background", "bypass")
TIMED_OUT = 75  # EX_TEMPFAIL
POLL_MAX = 10  # seconds between a long waiter's full looks at the queue
OVERTAKE_WINDOW = 600  # seconds a waiter that does not fit lets later requests that fit start first
QUEUE_ORDERS = ("backfill", "window")  # `slotfather order`; the first is the default
# The queue's order (order.json beside the queue, `slotfather order`; a client's environment may only tighten it):
# safety: a request passes the head only if this many times its estimate ends before the head can start;
# limit: seconds after the head queued from which nothing passes it, as in the window order (0: never);
# fallback: seconds a request with no run like it in the history is expected to run;
# overrun: a held lease past its estimate is expected to run on for this share of what it has run.
# Classes (#643): interactive: a waiter queues `interactive` seconds earlier than it came; batch: `batch` seconds
# later (0: neither moves). yield_after: an interactive waiter that has waited this long, and would not get slots
# within it, asks yieldable holders of a lower class to yield (0: nobody is asked).
ORDER_DEFAULTS = {"order": "backfill", "safety": 3.0, "limit": 2700.0, "fallback": 3600.0, "overrun": 0.5,
                  "interactive": 1800.0, "batch": 1800.0, "yield_after": 120.0}
# variable, least, how a client's environment tightens it: up (only higher counts), down (only lower), limit (a
# lower nonzero value; 0 is the loosest), delay (a higher value, or 0, the tightest).
ORDER_KNOBS = {"safety": ("BACKFILL_SAFETY", 1.0, "up"), "limit": ("BACKFILL_LIMIT", 0.0, "limit"),
               "fallback": ("BACKFILL_FALLBACK", 0.0, "up"), "overrun": ("BACKFILL_OVERRUN", 0.0, "down"),
               "interactive": ("PRIORITY_INTERACTIVE", 0.0, "down"), "batch": ("PRIORITY_BATCH", 0.0, "down"),
               "yield_after": ("YIELD_AFTER", 0.0, "delay")}
ORDER_BASE = ("order", "safety", "limit", "fallback", "overrun")  # always saved; the rest only when not the default
CLASSES = ("interactive", "normal", "batch")  # `run --class`, or the lease metadata's `class`; normal by default
YIELDS_MAX = 2  # times one lease is asked to yield
ASKERS = ("interactive",)  # the classes whose waiters ask (the replay found nothing in letting normal ones ask)
YIELD_BEHIND = 0.001  # seconds behind the waiter it yields to that a yielded lease queues
SHELLS = ("sh", "bash", "zsh", "dash", "fish")
ESTIMATE_RUNS = 20  # recent runs of a kind its estimate takes the median of
ESTIMATE_BYTES = 1 << 20  # of the history's end (and of its rotated part) read for estimates
UNFINISHED = ("reaped", "left")  # history outcomes whose time is no run of their kind: left out of the estimates
ESTIMATES_VERSION = 2  # estimates.json: 2 leaves UNFINISHED out; a file without it (or older) is worked out again
HISTORY_MAX = 4 << 20  # bytes of history.jsonl; past it the file becomes history.jsonl.1, replacing the older one
# history.jsonl lines: version 1 had no "v" field and no usage; version 2 adds "v", what a `run` used (cpu,
# cpu_detached, wall, rss_peak_mb, rss_mean_mb, processes, samples) and the machine's cores and capacity.
HISTORY_VERSION = 2
MACHINE_VERSION = 1  # machine.jsonl lines
MACHINE_MAX = 4 << 20  # bytes of machine.jsonl before it becomes machine.jsonl.1
MACHINE_EVERY = 15  # seconds between machine samples while any lease runs
SAMPLE_FIRST = 0.5  # seconds before a holder's first look at its command's process tree
SAMPLE_MAX = 10  # longest interval between those looks; each is half as long again as the one before
PS_TIMEOUT = 5  # seconds a ps or sysctl of the sampler may take before its answer is given up
WATCH_JOIN = 5  # seconds a release waits for the sampler to stop, and for its lock; then it goes without
ALL_NOTE = ("-n all holds every later request behind it until the whole machine is free; use it only for work that "
            "needs the machine to itself, such as a performance measurement, and otherwise ask for the slots the "
            "command uses")
# The variables a lease hands its command; a client may add its own prefix (Straylight's STRAYLIGHT_SLOT_).
LEASE_ENV_PREFIXES = ["SLOTFATHER_"]
# Lease metadata (#650, `run --meta key=value`): who asked and why (ticket, lane, phase, model, session ...), kept on
# the queue entry and in the history. Keys are short lowercase words; values short printable text.
META_KEY = re.compile(r"[a-z][a-z0-9_.-]{0,31}")
META_VALUE_MAX = 200
META_KEYS_MAX = 16


class SlotError(Exception):
    pass


class SlotTimeout(SlotError):
    pass


# Configuration

def setting(name: str, default: str | None = None) -> str | None:
    """SLOTFATHER_<name>, read when needed; a client that loads this file may replace this function to add its own
    spellings (tools/slot_lease.py)."""
    value = os.environ.get("SLOTFATHER_" + name)
    return default if value is None else value


def state_dir() -> Path:
    return Path(os.path.expanduser(setting("DIR") or DEFAULT_DIR))


def cores() -> int:
    value = setting("CORES") or ""
    return int(value) if value.isdigit() and int(value) > 0 else os.cpu_count() or 1


def memory_gib(group: str | None = None) -> float | None:
    """The memory the queue's leases share, in GiB (SLOTFATHER_MEMORY_GIB replaces it), or None where unknown: on
    Linux the limit of `group` (else of the queue's cgroup, memory_cgroup(); "" for none) where it has one, else the
    machine's."""
    value = setting("MEMORY_GIB") or ""
    with contextlib.suppress(ValueError):
        if float(value) > 0:
            return float(value)
    if linux():
        # A cgroup's limit alone where there is one: MemTotal moves with a VM's balloon, and stays in the guard.
        limit = cgroup_limit(memory_cgroup() if group is None else group)
        if limit is not None:
            return limit / (1 << 30)
        found = meminfo().get("MemTotal")
        return found / (1 << 20) if found else None
    if sys.platform == "darwin":
        found = sysctl("hw.memsize")
        return int(found) / (1 << 30) if found and found.isdigit() else None
    with contextlib.suppress(ValueError, OSError, AttributeError):
        return os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE") / (1 << 30)
    return None


def memory_slots(gib: float | None, per_slot: float) -> int | None:
    """One slot per `per_slot` GiB of `gib`, at least one; None when the memory is unknown. The memory counts in whole
    GiB, rounded: Linux's MemTotal is a little under the size a VM was given (11.7 for 12)."""
    if gib is None:
        return None
    return max(1, math.floor(round(gib) / per_slot + 1e-9))


def capacity_basis() -> dict:
    """The capacity and how it was found: {"slots", "saved", "mode", "cores", "cpu_slots", "memory_gib",
    "gib_per_slot", "memory_slots"}. Mode "fixed" is a saved count, "memory" one slot per gib_per_slot GiB, "lower"
    the lower of the CPU and memory budgets, "automatic" the lower at AUTO_GIB_PER_SLOT; atomic publication keeps
    readers consistent."""
    path = state_dir() / "capacity.json"
    machine = cores()
    cpu = max(1, machine // CORES_PER_SLOT)
    found = {"saved": True, "cores": machine, "cpu_slots": cpu, "memory_gib": None, "gib_per_slot": None,
             "memory_slots": None, "cgroup": None}
    try:
        data = json.loads(path.read_text())
        value = data["slots"]
    except FileNotFoundError:
        data, value = {"mode": "automatic", "gib_per_slot": AUTO_GIB_PER_SLOT}, None
        found["saved"] = False
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise SlotError(f"cannot read capacity from {path}: {error}") from None
    invalid = SlotError(f"invalid saved capacity in {path}; use slotfather slots reset while the queue is idle")
    if value is not None and (type(value) is not int or value < 1):
        raise invalid
    mode = data.get("mode", "fixed")
    if mode == "fixed":
        return {**found, "slots": value, "mode": mode}
    per_slot = data.get("gib_per_slot")
    if mode not in CAPACITY_MODES + ("automatic",) or type(per_slot) not in (int, float) or not per_slot > 0:
        raise invalid
    group = data.get("cgroup") if isinstance(data.get("cgroup"), str) else None
    gib = memory_gib(group)
    by_memory = memory_slots(gib, per_slot)
    found.update(mode=mode, gib_per_slot=per_slot, memory_slots=by_memory,
                 memory_gib=None if gib is None else round(gib, 1), cgroup=group or memory_cgroup())
    if by_memory is None:  # memory unknown: the count saved with the mode, or the CPU budget
        slots = value or cpu
    else:
        slots = by_memory if mode == "memory" else min(cpu, by_memory)
    return {**found, "slots": slots}


def automatic_capacity() -> int:
    """The capacity with nothing saved: the lower of the CPU budget and one slot per AUTO_GIB_PER_SLOT GiB."""
    by_memory = memory_slots(memory_gib(), AUTO_GIB_PER_SLOT)
    cpu = max(1, cores() // CORES_PER_SLOT)
    return cpu if by_memory is None else min(cpu, by_memory)


def capacity() -> tuple[int, bool]:
    """The shared saved capacity, or the automatic default: (slots, saved)."""
    found = capacity_basis()
    return found["slots"], found["saved"]


def capacity_text(found: dict) -> str:
    """`slotfather slots`' line: "N slots (saved)", "N slots (automatic)", with the budgets where memory counts."""
    slots, mode = found["slots"], found["mode"]
    if mode == "fixed":
        return f"{slots} slots (saved)"
    memory = f"{found['memory_gib']:g} GiB" if found["memory_gib"] is not None else "unknown memory"
    if found.get("cgroup") and found["memory_gib"] is not None and not setting("MEMORY_GIB"):
        memory += f" in {found['cgroup']}"
    per = f"one per {found['gib_per_slot']:g} GiB of {memory}"
    cpu = f"{found['cpu_slots']} by {found['cores']} cores"
    if mode == "automatic":
        if found["memory_slots"] is None or found["memory_slots"] >= found["cpu_slots"]:
            return f"{slots} slots (automatic)"
        return f"{slots} slots (automatic, by memory: {per}; {cpu})"
    if mode == "memory":
        return f"{slots} slots (saved: {per})"
    return f"{slots} slots (saved: the lower of {cpu} and {found['memory_slots'] or '?'} by memory, {per})"


def total() -> int:
    return capacity()[0]


def loads() -> tuple[float, float, float]:
    """The 1, 5 and 15-minute load averages."""
    value = (setting("LOADAVG") or "").split()
    with contextlib.suppress(ValueError):
        if len(value) == 1:
            return (float(value[0]),) * 3
        if len(value) == 3:
            return tuple(float(v) for v in value)
    return os.getloadavg()


def overtake_window() -> float:
    """SLOTFATHER_OVERTAKE_WINDOW in seconds; a value that is not a number serves strictly in order."""
    try:
        return max(0.0, float(setting("OVERTAKE_WINDOW") or OVERTAKE_WINDOW))
    except ValueError:
        return 0.0


def legacy_dirs() -> list[Path]:
    value = setting("LEGACY_DIRS", DEFAULT_LEGACY_DIRS)
    own = state_dir().resolve()
    paths = [Path(os.path.expanduser(p)) for p in value.split(":") if p]
    return [p for p in paths if p.resolve() != own]


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def seconds(stamp) -> float | None:
    """A now() stamp as epoch seconds, or None."""
    try:
        return datetime.datetime.strptime(stamp, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=datetime.timezone.utc).timestamp()
    except (TypeError, ValueError):
        return None


def duration(value: float) -> str:
    value = int(value)
    if value >= 3600:
        return f"{value // 3600}h{value % 3600 // 60:02d}m"
    return f"{value // 60}m{value % 60:02d}s" if value >= 60 else f"{value}s"


# Processes

def ps_environment() -> dict | None:
    """The environment ps runs in for processes(): on Linux the C locale, since procps writes lstart in the locale's
    words and every client must write a holder's start alike; macOS keeps the caller's, as clients before #653 did."""
    return {**os.environ, "LC_ALL": "C"} if sys.platform.startswith("linux") else None


def processes() -> dict[int, tuple[int, str]]:
    """Live pid -> (ppid, start time); the start time tells a reused pid from the holder. Zombies are dead. The same
    ps flags serve macOS and Linux (procps-ng)."""
    result = subprocess.run(["ps", "-axo", "pid=,ppid=,stat=,lstart="], capture_output=True, text=True,
                            env=ps_environment())
    table = {}
    for line in result.stdout.splitlines():
        parts = line.split(None, 3)
        if len(parts) == 4 and parts[0].isdigit() and parts[1].isdigit() and not parts[2].startswith("Z"):
            table[int(parts[0])] = (int(parts[1]), parts[3].strip())
    return table


def ancestors(table: dict, pid: int) -> set[int]:
    found = set()
    while pid in table and pid not in found and pid > 1:
        found.add(pid)
        pid = table[pid][0]
    return found


def alive(entry: dict, table: dict) -> bool:
    process = table.get(entry.get("pid"))
    return process is not None and entry.get("start") in ("", process[1])


# Memory

def number_setting(name: str, default: float) -> float:
    try:
        return float(setting(name) or default)
    except ValueError:
        return default


def memory_short() -> str | None:
    """Why new leases should wait for memory, or None. macOS: free swap and the kernel's memory-pressure level;
    Linux: free swap, MemAvailable and PSI (linux_short())."""
    seam = setting("MEMORY_FILE")  # test seam: "<free swap MB> <pressure level>"
    if seam:
        try:
            free, level = (float(v) for v in Path(seam).read_text().split()[:2])
        except (OSError, ValueError):
            return None
    elif linux():
        return linux_short(linux_memory())
    else:
        free, level = swap_free_mb(), pressure_level()
    floor = number_setting("MIN_FREE_SWAP_MB", MIN_FREE_SWAP_MB)
    if free is not None and free < floor:
        return f"free swap {free:.0f} MB is under {floor:.0f} MB"
    if level is not None and level > MAX_PRESSURE_LEVEL:
        return f"memory pressure level {level:.0f} (warning or critical)"
    return None


def linux() -> bool:
    """Whether memory and processes are read from /proc: on Linux, or wherever SLOTFATHER_PROC names a /proc."""
    return sys.platform.startswith("linux") or bool(setting("PROC"))


def proc_path(*parts: str) -> Path:
    return Path(setting("PROC") or "/proc", *parts)


def meminfo(text: str | None = None) -> dict[str, int]:
    """/proc/meminfo as name -> kB (counts without a unit as they are); {} where it cannot be read."""
    if text is None:
        try:
            text = proc_path("meminfo").read_text()
        except OSError:
            return {}
    found = {}
    for line in text.splitlines():
        name, _, rest = line.partition(":")
        value = rest.split()
        if value and value[0].isdigit():
            found[name.strip()] = int(value[0])
    return found


def psi(text: str | None = None) -> dict[str, float] | None:
    """avg10 of /proc/pressure/memory's "some" and "full" lines, in percent: {"some": x, "full": y}; None where the
    kernel does not expose PSI (built without it, booted with psi=0, or a container that hides it)."""
    if text is None:
        try:
            text = proc_path("pressure", "memory").read_text()
        except OSError:
            return None
    found = {}
    for line in text.splitlines():
        kind, *fields = line.split()
        for field in fields:
            name, _, value = field.partition("=")
            if name == "avg10" and kind in ("some", "full"):
                with contextlib.suppress(ValueError):
                    found[kind] = float(value)
    return found or None


def cgroup_path(group: str) -> Path:
    """A cgroup v2 path ("/ci.slice/ci-runners.slice") in the mounted hierarchy (SLOTFATHER_CGROUP_ROOT replaces
    /sys/fs/cgroup, a test seam)."""
    return Path(setting("CGROUP_ROOT") or "/sys/fs/cgroup", group.strip("/"))


def cgroup_value(group: str | None, name: str) -> int | None:
    """A cgroup's memory.max or memory.current in bytes; None for no group, "max" (no limit) or a file not there."""
    if not group:
        return None
    try:
        value = (cgroup_path(group) / name).read_text().strip()
    except OSError:
        return None
    return int(value) if value.isdigit() else None


def cgroup_limit(group: str | None) -> int | None:
    """A cgroup's effective memory limit in bytes: the smallest memory.max on its path from the root; None for none."""
    if not group:
        return None
    parts = [p for p in group.strip("/").split("/") if p]
    limits = [cgroup_value("/" + "/".join(parts[:n]), "memory.max") for n in range(len(parts) + 1)]
    return min((v for v in limits if v is not None), default=None)


def own_cgroup() -> str | None:
    """This process's cgroup v2 path, from /proc/self/cgroup's "0::" line; None on cgroup v1 or off Linux."""
    with contextlib.suppress(OSError):
        for line in proc_path("self", "cgroup").read_text().splitlines():
            if line.startswith("0::"):
                return line[3:].strip() or "/"
    return None


def limited_cgroup(group: str | None = None) -> str | None:
    """The outermost cgroup at or above `group` (default this process's) with a memory limit: on a CI VM whose
    runner services each have a MemoryMax inside a slice with a MemoryMax of its own, the slice all of them share."""
    group = own_cgroup() if group is None else group
    if not group:
        return None
    parts, found = [p for p in group.strip("/").split("/") if p], None
    for n in range(len(parts), -1, -1):  # "/" last: a host's root has no memory.max, a container's namespace may
        candidate = "/" + "/".join(parts[:n])
        if cgroup_value(candidate, "memory.max") is not None:
            found = candidate
    return found


def memory_cgroup() -> str | None:
    """The cgroup whose memory the queue's leases share: SLOTFATHER_CGROUP, else the one install.py --cgroup wrote
    in (DEFAULT_CGROUP), else the one saved with the capacity
    (`slots memory|lower` saves the saver's), else this process's limited_cgroup(); None off Linux or without a
    limit. Every client of a queue should name the same one: the capacity and the guard read its limit and pressure."""
    if not linux():
        return None
    named = setting("CGROUP") or DEFAULT_CGROUP
    if named:
        return named
    with contextlib.suppress(OSError, ValueError, AttributeError):
        saved = json.loads((state_dir() / "capacity.json").read_text()).get("cgroup")
        if isinstance(saved, str) and saved.startswith("/"):
            return saved
    return limited_cgroup()


def linux_memory(info: dict[str, int] | None = None, pressure: dict | None = None,
                 group: str | None = None) -> dict:
    """The Linux memory facts in MB and percent: total, available, swap_total, swap_free, psi_some, psi_full, and
    for the queue's cgroup (memory_cgroup(), or `group`) cgroup, cgroup_max and cgroup_available (None where not
    reported). PSI is the cgroup's memory.pressure where there is one, else /proc/pressure/memory's."""
    info = meminfo() if info is None else info
    group = memory_cgroup() if group is None else group
    limit = cgroup_limit(group)
    if pressure is None and group:
        with contextlib.suppress(OSError):
            pressure = psi((cgroup_path(group) / "memory.pressure").read_text())
    pressure = psi() if pressure is None else pressure
    megabytes = {key: (info[name] / 1024 if name in info else None)
                 for key, name in (("total", "MemTotal"), ("available", "MemAvailable"),
                                   ("swap_total", "SwapTotal"), ("swap_free", "SwapFree"))}
    if megabytes["available"] is None and "MemFree" in info:  # kernels before 3.14 have no MemAvailable
        megabytes["available"] = (info["MemFree"] + info.get("Cached", 0) + info.get("Buffers", 0)) / 1024
    used = cgroup_value(group, "memory.current") if limit is not None else None
    if used is not None:  # the working set: the cgroup's page cache it can drop at once does not count
        with contextlib.suppress(OSError, ValueError):
            for line in (cgroup_path(group) / "memory.stat").read_text().splitlines():
                if line.startswith("inactive_file "):
                    used = max(0, used - int(line.split()[1]))
    return {**megabytes, "psi_some": (pressure or {}).get("some"), "psi_full": (pressure or {}).get("full"),
            "cgroup": group if limit is not None else None, "cgroup_max": None if limit is None else limit / (1 << 20),
            "cgroup_available": None if used is None else max(0, limit - used) / (1 << 20)}


def linux_short(facts: dict) -> str | None:
    """Why new leases should wait, from linux_memory(): free swap under its floor (where swap is on), MemAvailable
    under SLOTFATHER_MIN_AVAILABLE_MB, or PSI avg10 at SLOTFATHER_MAX_PSI_SOME / _FULL percent or above."""
    floor = number_setting("MIN_FREE_SWAP_MB", MIN_FREE_SWAP_MB)
    if facts["swap_total"] and facts["swap_free"] is not None and facts["swap_free"] < floor:
        return f"free swap {facts['swap_free']:.0f} MB is under {floor:.0f} MB"
    least = number_setting("MIN_AVAILABLE_MB", MIN_AVAILABLE_MB)
    if facts["available"] is not None and facts["available"] < least:
        return f"available memory {facts['available']:.0f} MB is under {least:.0f} MB"
    if facts.get("cgroup_available") is not None and facts["cgroup_available"] < least:
        return (f"memory left under {facts['cgroup']}'s limit, {facts['cgroup_available']:.0f} MB, is under "
                f"{least:.0f} MB")
    for kind, name, default in (("some", "MAX_PSI_SOME", MAX_PSI_SOME), ("full", "MAX_PSI_FULL", MAX_PSI_FULL)):
        value, limit = facts["psi_" + kind], number_setting(name, default)
        if value is not None and limit > 0 and value >= limit:
            return f"memory pressure: PSI {kind} avg10 {value:g}% (limit {limit:g}%)"
    return None


def sysctl(name: str) -> str | None:
    try:
        result = subprocess.run(["sysctl", "-n", name], capture_output=True, text=True, timeout=PS_TIMEOUT)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() if result.returncode == 0 else None


def swap_usage(report: str | None = None) -> tuple[float, float] | None:
    """(total, free) swap in MB from `sysctl vm.swapusage` (Linux: /proc/meminfo), or None where the host does not
    report it."""
    if report is None and linux():
        facts = linux_memory(pressure={})
        return None if facts["swap_total"] is None else (facts["swap_total"], facts["swap_free"] or 0.0)
    found = re.search(r"total = ([\d.]+)([MG]).*?free = ([\d.]+)([MG])",
                      (sysctl("vm.swapusage") or "") if report is None else report)
    if not found:
        return None
    return tuple(float(found[n]) * (1024 if found[n + 1] == "G" else 1) for n in (1, 3))


def swap_free_mb(report: str | None = None) -> float | None:
    """Free swap in MB, or None when there is no swap to run short of: with swap turned off the kernel reports
    0 MB free at all times, and the floor would hold every lease behind the one running."""
    usage = swap_usage(report)
    return usage[1] if usage and usage[0] > 0 else None


def pressure_level() -> float | None:
    """macOS's memory-pressure level (1 normal, 2 warning, 4 critical); None elsewhere."""
    if linux():
        return None
    value = sysctl("kern.memorystatus_vm_pressure_level")
    return float(value) if value and value.isdigit() else None


# Usage: what a lease's process tree used, and what the machine did meanwhile

def cpu_seconds(text: str) -> float | None:
    """ps `time` ([days-][hours:]minutes:seconds.fraction) as seconds, or None."""
    days, _, rest = text.strip().rpartition("-")
    try:
        value = 0.0
        for part in rest.split(":"):
            value = value * 60 + float(part)
        return value + (int(days) * 86400 if days else 0)
    except ValueError:
        return None


def started_at(lstart: str) -> float | None:
    """A `ps -o lstart` time (C locale) as epoch seconds, or None."""
    try:
        return time.mktime(time.strptime(" ".join(lstart.split()), "%a %b %d %H:%M:%S %Y"))
    except ValueError:
        return None


def proc_cpu_seconds(pid: int, text: str | None = None) -> float | None:
    """utime + stime of /proc/PID/stat in seconds, or None. procps' `time` counts whole seconds, which loses the
    short processes a lease's tree is full of; /proc counts clock ticks (10 ms)."""
    if text is None:
        try:
            text = proc_path(str(pid), "stat").read_text()
        except OSError:
            return None
    fields = text.rpartition(")")[2].split()  # after the command name, which may hold spaces and parentheses
    try:
        return (int(fields[11]) + int(fields[12])) / os.sysconf("SC_CLK_TCK")
    except (IndexError, ValueError, OSError):
        return None


def usage_table() -> dict[int, tuple[int, str, int, int, float]]:
    """Live pid -> (ppid, start, uid, resident KB, CPU seconds of its own), from one ps over the machine (on Linux
    the CPU from /proc/PID/stat where it can be read). Raises SlotError when ps fails or takes longer than
    PS_TIMEOUT."""
    try:
        result = subprocess.run(["ps", "-axo", "pid=,ppid=,uid=,rss=,time=,lstart="], capture_output=True,
                                text=True, env={**os.environ, "LC_ALL": "C"}, timeout=PS_TIMEOUT)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise SlotError(f"ps: {error}") from None
    table = {}
    for line in result.stdout.splitlines():
        parts = line.split(None, 5)
        if len(parts) == 6 and all(p.isdigit() for p in parts[:4]):
            cpu = cpu_seconds(parts[4])
            if linux():
                cpu = proc_cpu_seconds(int(parts[0])) or cpu
            if cpu is not None:
                table[int(parts[0])] = (int(parts[1]), parts[5].strip(), int(parts[2]), int(parts[3]), cpu)
    return table


def carrying(pids: list[int], lease: str) -> set[int]:
    """Those of `pids` whose environment holds SLOTFATHER_LEASE=<lease>. macOS shows another process's environment
    only for the user's own processes that are not platform binaries; Linux (/proc/PID/environ) only for the user's
    own (all of them for root); the rest read as not carrying it."""
    if not pids:
        return set()
    if linux():
        wanted = ("SLOTFATHER_LEASE=" + lease).encode()
        found = set()
        for pid in pids:
            with contextlib.suppress(OSError):
                if wanted in proc_path(str(pid), "environ").read_bytes().split(b"\0"):
                    found.add(pid)
        return found
    try:
        result = subprocess.run(["ps", "-wwE", "-o", "pid=,command=", "-p", ",".join(map(str, pids))],
                                capture_output=True, text=True, env={**os.environ, "LC_ALL": "C"}, timeout=PS_TIMEOUT)
    except (OSError, subprocess.TimeoutExpired):
        return set()
    mark = " SLOTFATHER_LEASE=" + lease
    found = set()
    for line in result.stdout.splitlines():
        pid, _, rest = line.strip().partition(" ")
        at = (" " + rest).find(mark)
        tail = (" " + rest)[at + len(mark):] if at >= 0 else None
        if pid.isdigit() and tail is not None and (not tail or tail[0] == " "):
            found.add(int(pid))
    return found


class TreeUsage:
    """CPU and memory of one command's process tree, from snapshots of the process table.

    A process is the lease's while it descends from the command (attached), and stays the lease's after its parent
    exits and launchd adopts it (detached); a child of launchd started during the lease joins it when its
    environment carries the lease (`marked`). CPU time of every process an attached parent reaps reaches the
    command's own rusage at its exit, so it is not summed here; a detached process is reaped by launchd, so its CPU
    is the last sample of its own time (Linux: init adopts and reaps, as launchd does; an orphan adopted by another
    child subreaper, such as `systemd --user`, is followed only once seen in the tree). Processes born and gone
    between two samples outside the attached tree are not seen, nor is a child that exits unwaited-for before its parent exits (launchd reaps that zombie). Resident
    memory is the sum over the tree's processes (shared pages count once per process)."""

    def __init__(self, root: int, since: float, marked=None, uid: int | None = None):
        self.root, self.since = root, since
        self.marked = marked or (lambda pids: set())
        self.uid = os.getuid() if uid is None else uid
        self.root_start = None
        self.root_gone = False  # set once wait4 has reaped the command: its pid may then be another process
        self.members = {}  # (pid, start) -> [own CPU seconds at the last sample, attached]
        self.checked = set()  # (pid, start) of launchd children already considered
        self.detached_gone = 0.0
        self.processes = self.samples = 0
        self.rss_peak = 0  # KB
        self.rss_area = self.span = 0.0  # KB x seconds, seconds
        self.last = None  # (moment, resident KB) of the previous sample

    def candidates(self, table: dict) -> list[int]:
        """Children of launchd started during the lease that have not been considered yet; each is returned once,
        for `marked` to say whether it carries the lease."""
        fresh = []
        for pid, row in table.items():
            key = (pid, row[1])
            if row[0] == 1 and row[2] == self.uid and key not in self.members and key not in self.checked:
                self.checked.add(key)
                begun = started_at(row[1])
                if begun is not None and begun >= self.since - 1:
                    fresh.append(pid)
        return fresh

    def observe(self, moment: float, table: dict, adopted: set[int] | None = None) -> None:
        """Takes in one process table. `adopted` are the candidates() of this table that carry the lease; without
        it observe asks `marked` itself."""
        if adopted is None:
            fresh = self.candidates(table)
            adopted = self.marked(fresh) if fresh else set()
        for key in list(self.members):
            row = table.get(key[0])
            if row is None or row[1] != key[1]:
                cpu, attached = self.members.pop(key)
                if not attached:
                    self.detached_gone += cpu
        children = {}
        for pid, row in table.items():
            children.setdefault(row[0], []).append(pid)

        def tree(roots) -> set[int]:
            found, stack = set(), [p for p in roots if p in table]
            while stack:
                pid = stack.pop()
                if pid not in found:
                    found.add(pid)
                    stack.extend(children.get(pid, ()))
            return found

        if self.root_start is None and self.root in table and not self.root_gone:
            self.root_start = table[self.root][1]
        attached = set() if self.root_gone or self.root not in table or table[self.root][1] != self.root_start \
            else tree([self.root])
        adopted = {pid for pid in adopted if pid in table}
        detached = tree([pid for pid, _ in self.members if pid not in attached] + list(adopted)) - attached
        resident = 0
        for pid in attached | detached:
            row = table[pid]
            key = (pid, row[1])
            if key not in self.members:
                self.processes += 1
            self.members[key] = [row[4], pid in attached]
            resident += row[3]
        if self.last is not None:
            self.rss_area += self.last[1] * (moment - self.last[0])
            self.span += moment - self.last[0]
        self.last = (moment, resident)
        self.rss_peak = max(self.rss_peak, resident)
        self.samples += 1

    def detached(self) -> float:
        """CPU seconds of processes that left the attached tree: gone, and still running at the last sample."""
        return self.detached_gone + sum(cpu for cpu, attached in self.members.values() if not attached)

    def result(self, reaped_cpu: float, reaped_peak_kb: int = 0, wall: float | None = None) -> dict:
        """Usage for the history, once the command has exited and the last sample was taken after its exit:
        `reaped_cpu` and `reaped_peak_kb` come from the command's rusage."""
        detached = self.detached()
        mean = self.rss_area / self.span if self.span > 0 else (self.last[1] if self.last else 0)
        found = {"cpu": round(reaped_cpu + detached, 2), "cpu_detached": round(detached, 2),
                 "rss_peak_mb": round(max(self.rss_peak, reaped_peak_kb) / 1024, 1),
                 "rss_mean_mb": round(mean / 1024, 1), "processes": self.processes, "samples": self.samples}
        if wall is not None:
            found["wall"] = round(wall, 2)
        return found


class Watch(threading.Thread):
    """The holder's sampler: looks at the command's tree, first after SAMPLE_FIRST seconds and then half as long
    again each time up to SLOTFATHER_SAMPLE_MAX, and samples the machine when no holder has lately. A fault here
    never reaches the lease: the history then lacks what could not be measured."""

    def __init__(self, usage: TreeUsage, directory: Path):
        super().__init__(daemon=True, name="slotfather-watch")
        self.usage, self.directory = usage, directory
        try:
            self.most = max(0.05, float(setting("SAMPLE_MAX") or SAMPLE_MAX))
        except ValueError:
            self.most = SAMPLE_MAX
        self.stopped = threading.Event()
        self.lock = threading.Lock()

    def observe(self) -> None:
        """One look at the tree. The ps calls run outside the lock, so finish() never waits on a slow ps for it."""
        moment, table = time.time(), usage_table()
        with self.lock:
            fresh = self.usage.candidates(table)
        adopted = self.usage.marked(fresh) if fresh else set()
        with self.lock:
            self.usage.observe(moment, table, adopted)

    def look(self) -> None:
        with contextlib.suppress(Exception):
            self.observe()
        with contextlib.suppress(Exception):
            sample_machine(self.directory)

    def run(self) -> None:
        # Signals for the holder (forwarded to its command) must interrupt the holder's wait4, not this thread.
        with contextlib.suppress(AttributeError, OSError, ValueError):
            signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM, signal.SIGHUP, signal.SIGINT})
        interval = min(SAMPLE_FIRST, self.most)
        while not self.stopped.wait(interval):
            self.look()
            interval = min(interval * 1.5, self.most)

    def finish(self, rusage, wall: float) -> dict | None:
        """Stops sampling, takes the last look (after the command exited) and returns the usage. Waits at most
        WATCH_JOIN seconds for the sampler, and skips the last look when it is still stuck: the release goes on."""
        self.usage.root_gone = True
        self.stopped.set()
        self.join(timeout=WATCH_JOIN)
        if not self.is_alive():
            with contextlib.suppress(Exception):
                self.observe()
        if rusage is None or not self.lock.acquire(timeout=WATCH_JOIN):
            return None
        try:
            peak = rusage.ru_maxrss // 1024 if sys.platform == "darwin" else rusage.ru_maxrss  # bytes on macOS
            return self.usage.result(rusage.ru_utime + rusage.ru_stime, peak, wall)
        except Exception:  # noqa: BLE001 - measuring must never cost the lease its release
            return None
        finally:
            self.lock.release()


_host_port = None


def cpu_ticks() -> list[int] | None:
    """Cumulative CPU ticks of the whole machine: [user, system, idle, nice], or None where unavailable."""
    global _host_port
    if sys.platform == "darwin":
        try:
            import ctypes
            libc = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
            if _host_port is None:
                libc.mach_host_self.restype = ctypes.c_uint
                _host_port = libc.mach_host_self()
            counts, size = (ctypes.c_uint * 4)(), ctypes.c_uint(4)
            if libc.host_statistics(_host_port, 3, counts, ctypes.byref(size)) == 0:  # HOST_CPU_LOAD_INFO
                return list(counts)
        except (OSError, AttributeError):
            return None
        return None
    with contextlib.suppress(OSError, ValueError):
        fields = Path("/proc/stat").read_text().split("\n", 1)[0].split()[1:]
        user, nice, system, idle = (int(v) for v in fields[:4])
        return [user, system, idle + sum(int(v) for v in fields[4:5]), nice]  # iowait counts as idle
    return None


def machine_facts(directory: Path) -> dict:
    """One machine sample: load, cumulative CPU ticks (busy is the change between two samples), memory pressure,
    swap and the slots held."""
    held = [e for _, e in entries(directory) if e.get("state") == "held"]
    linux_facts = linux_memory() if linux() else None
    if linux_facts is None:
        swap = swap_usage()
        level = pressure_level()
        free = sysctl("kern.memorystatus_level")
        free = int(free) if free and free.isdigit() else None
    else:  # Linux: free memory is MemAvailable's share; no pressure level, PSI instead
        swap = None if linux_facts["swap_total"] is None else (linux_facts["swap_total"], linux_facts["swap_free"] or 0)
        level = None
        free = round(100 * linux_facts["available"] / linux_facts["total"]) \
            if linux_facts["available"] is not None and linux_facts["total"] else None
    item = {"v": MACHINE_VERSION, "t": now(), "at": round(time.time(), 2),
            "load": [round(v, 2) for v in os.getloadavg()], "ticks": cpu_ticks(), "cores": cores(),
            "pressure": level, "memory_free_pct": free,
            "swap_total_mb": None if swap is None else round(swap[0]),
            "swap_free_mb": None if swap is None else round(swap[1]),
            "held": sum(e["count"] for e in held), "leases": len(held)}
    if linux_facts is not None:
        item.update(memory_available_mb=None if linux_facts["available"] is None else round(linux_facts["available"]),
                    psi_some=linux_facts["psi_some"], psi_full=linux_facts["psi_full"])
        if linux_facts["cgroup"]:
            item.update(cgroup=linux_facts["cgroup"], cgroup_max_mb=round(linux_facts["cgroup_max"]),
                        cgroup_available_mb=None if linux_facts["cgroup_available"] is None
                        else round(linux_facts["cgroup_available"]))
    with contextlib.suppress(SlotError):
        item["capacity"] = total()
    return item


def sample_machine(directory: Path) -> bool:
    """Appends a machine sample unless one was taken in the last SLOTFATHER_MACHINE_EVERY seconds; holders share
    the duty through machine.jsonl's age and a lock of its own, never the queue's."""
    path = directory / "machine.jsonl"
    try:
        every = float(setting("MACHINE_EVERY") or MACHINE_EVERY)
    except ValueError:
        every = MACHINE_EVERY

    def due() -> bool:
        try:
            return time.time() - path.stat().st_mtime >= every
        except FileNotFoundError:
            return True
    if not due():
        return False
    with open(directory / ".machine.lock", "a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        if not due():
            return False
        append_bounded(path, json.dumps(machine_facts(directory)) + "\n", MACHINE_MAX)
        return True


# Queue

def foreign_owner(directory: Path) -> int | None:
    """The uid that owns the queue when it is not this process's (effective) one, else None. A queue not made yet
    belongs to the owner of the directory it would be made in, unless that is a sticky shared one such as /tmp.
    Another user's queue is read only (#653 review: root through the guest agent running the installed command
    must not leave root's files in the runner's queue)."""
    path = Path(directory)
    while not os.path.lexists(path) and path != path.parent:
        path = path.parent
    try:
        info = path.stat()
    except OSError:
        return None
    if info.st_uid == os.geteuid() or (path != Path(directory) and info.st_mode & stat.S_ISVTX):
        return None
    return info.st_uid


def require_own(directory: Path, what: str) -> None:
    """Refuses `what`, a change to the queue, from a user other than the queue's owner."""
    owner = foreign_owner(directory)
    if owner is None:
        return
    try:
        name = pwd.getpwuid(owner).pw_name
    except KeyError:
        name = str(owner)
    raise SlotError(f"the queue {directory} belongs to uid {owner} ({name}): {what} by uid {os.geteuid()} would leave "
                    f"files that user cannot write; run it as that user: sudo -u {name} slotfather ...")


@contextlib.contextmanager
def locked(directory: Path):
    """The queue's lock. In another user's queue (foreign_owner()) nothing is created: an existing lock is taken
    through a read-only handle, a missing queue is read as it is."""
    if foreign_owner(directory) is not None:
        try:
            handle = open(directory / ".lock", "r")
        except OSError:
            yield
            return
        with handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            yield
        return
    (directory / "queue").mkdir(parents=True, exist_ok=True)
    with open(directory / ".lock", "a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield


def entries(directory: Path) -> list[tuple[Path, dict]]:
    found = []
    for path in sorted((directory / "queue").glob("*.json")):
        try:
            entry = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if isinstance(entry, dict) and isinstance(entry.get("count"), int):
            found.append((path, entry))
    return found


def write(path: Path, entry: dict) -> None:
    pending = path.with_name(path.name + ".pending")
    pending.write_text(json.dumps(entry) + "\n")
    pending.replace(path)


def reap(directory: Path, table: dict) -> list[tuple[Path, dict]]:
    """Live entries in queue order; removes those whose holder exited or crashed (in another user's queue it only
    leaves them out)."""
    live = []
    readonly = foreign_owner(directory) is not None
    for path, entry in entries(directory):
        if alive(entry, table):
            live.append((path, entry))
        elif not readonly:
            path.unlink(missing_ok=True)
            marker(path).unlink(missing_ok=True)
            log(directory, f"reaped {entry.get('state')} lease of {entry.get('count')} for "
                           f"{entry.get('label')} (pid {entry.get('pid')} exited)")
            record(directory, entry, "reaped")
    return live


def record(directory: Path, entry: dict, outcome: str, status: int | None = None, usage: dict | None = None) -> None:
    """Add a request that left the queue to history.jsonl: released (it ran), left (it gave up waiting) or reaped
    (its holder died), with what its process tree used where the holder measured it. Callers hold the queue lock."""
    ended = time.time()
    queued, granted = seconds(entry.get("since")), seconds(entry.get("granted"))
    item = {"v": HISTORY_VERSION, "label": entry.get("label"), "cmd": entry.get("cmd"), "cwd": entry.get("cwd"),
            "count": entry.get("count"), "pid": entry.get("pid"), "queued": entry.get("since"),
            "granted": entry.get("granted"), "ended": now(), "outcome": outcome,
            "waited": None if queued is None else round((granted or ended) - queued),
            "ran": None if granted is None else round(ended - granted), "status": status}
    with contextlib.suppress(SlotError, OSError):
        item.update(cores=cores(), capacity=total())
    item.update(usage or {})
    if entry.get("yields"):
        yielded = float(entry.get("yielded") or 0)
        away = epoch(entry.get("yielded_at"))
        item.update(yields=int(entry["yields"]), yielded=round(yielded + (max(0.0, ended - away) if away else 0), 2))
    if entry.get("until"):
        item["until"] = entry["until"]  # when its client would have given up (run --wait): the replay's patience
    meta = meta_of(entry)
    if meta:
        item["meta"] = meta
    with contextlib.suppress(OSError):
        append_bounded(directory / "history.jsonl", json.dumps(item) + "\n", HISTORY_MAX)


def append_bounded(path: Path, line: str, limit: int) -> None:
    """Append a line; past `limit` bytes the file becomes <name>.1, replacing the previous one, so at most two
    files' worth stays. Readers read <name>.1 first, then <name>."""
    fd = os.open(path, os.O_RDWR | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        size = os.fstat(fd).st_size
        # A torn earlier write (a holder killed mid-line) must not swallow this line: start it on a line of its own.
        prefix = b"\n" if size and os.pread(fd, 1, size - 1) != b"\n" else b""
        os.write(fd, prefix + line.encode("utf-8"))  # one write, at the end even with other appenders
    finally:
        os.close(fd)
    if path.stat().st_size > limit:
        path.replace(path.with_name(path.name + ".1"))


def objects(lines) -> list[dict]:
    """The JSON objects among lines; lines that do not parse (a torn write, a foreign line) are skipped."""
    found = []
    for line in lines:
        with contextlib.suppress(ValueError, UnicodeDecodeError):
            item = json.loads(line)
            if isinstance(item, dict):
                found.append(item)
    return found


def journal(path: Path):
    """The JSON objects of a bounded file and its rotated predecessor, oldest first."""
    for part in (path.with_name(path.name + ".1"), path):
        try:
            data = part.read_bytes()
        except FileNotFoundError:
            continue
        yield from objects(data.splitlines())


def tail_objects(path: Path, limit: int) -> list[dict]:
    """The last `limit` JSON objects of one file, read backwards from its end in blocks."""
    try:
        handle = open(path, "rb")
    except FileNotFoundError:
        return []
    with handle:
        end = handle.seek(0, os.SEEK_END)
        block, data = 65536, b""
        while True:
            start = max(0, end - block)
            handle.seek(start)
            data = handle.read(end - start)
            lines = data.splitlines()
            found = objects(lines[1:] if start else lines)  # the first line of a block may be cut
            if len(found) >= limit or not start:
                return found[-limit:]
            block *= 4


def history_items(directory: Path | None = None) -> list[dict]:
    """Every request in history.jsonl (and its rotated part), oldest first. Version-1 lines read as they are: they
    lack "v" and the usage fields."""
    return list(journal((directory or state_dir()) / "history.jsonl"))


def history_lines(limit: int, directory: Path | None = None) -> list[str]:
    """The last `limit` requests that left the queue (every one for 0), oldest first. The rotated part is read only
    when the current file holds fewer."""
    path = (directory or state_dir()) / "history.jsonl"
    if limit:
        items = tail_objects(path, limit)
        if len(items) < limit:
            items = tail_objects(path.with_name(path.name + ".1"), limit - len(items)) + items
    else:
        items = list(journal(path))
    found = []
    for item in items:
        ended = seconds(item.get("ended"))
        when = time.strftime("%m-%d %H:%M", time.localtime(ended)) if ended is not None else "?"
        waited = "?" if item.get("waited") is None else duration(item["waited"])
        ran = "" if item.get("ran") is None else f" ran {duration(item['ran'])}"
        status = "" if item.get("status") is None else f" exit {item['status']}"
        used = ""
        if isinstance(item.get("cpu"), (int, float)):
            wall = item.get("wall") or item.get("ran")
            cores_used = f"{item['cpu'] / wall:.1f} cores" if wall else f"{item['cpu']:.0f} s CPU"
            used = f" used {cores_used}, {item.get('rss_peak_mb', 0):.0f} MB"
        meta = meta_of(item)
        tags = f" meta={meta_text(meta)}" if meta else ""
        found.append(f"{when} {item.get('outcome')}: {item.get('count')} slot(s) {item.get('label')} waited "
                     f"{waited}{ran}{status}{used}{tags} cmd={item.get('cmd')}")
    return found


def legacy_holders(table: dict) -> list[tuple[Path, dict, int]]:
    """Held leases with a live holder in the earlier queues: (path, entry, slots here). Read only: their own
    clients reap them."""
    found = []
    for directory in legacy_dirs():
        for path, entry in entries(directory):
            if entry.get("state") == "held" and alive(entry, table):
                found.append((path, entry, min(total(), math.ceil(entry["count"] * total() / LEGACY_TOTAL))))
    return found


def legacy_used(table: dict) -> int:
    return sum(count for _, _, count in legacy_holders(table))


def kind(command: str | None) -> str:
    """The kind of check a command is: its program's name and first argument; a comma list counts its items, a path
    keeps its last part, an option keeps its name, and a short option value follows it. `env` and VAR=value before
    the program go; a runner's `run` keeps what it runs (`bun run build`, `uv run pytest`), and a shell's `-c`
    script is the kind of the script's command (`sh -c bun run build`)."""
    words = [w for w in (command or "").split()]
    while words and (re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", words[0]) or os.path.basename(words[0]) == "env"):
        words.pop(0)  # env and VAR=value before the program
    if not words:
        return "?"
    found = [os.path.basename(words[0]) or words[0]]
    rest = words[1:]
    if rest and found[0] in SHELLS and re.fullmatch(r"-[a-z]*c", rest[0]) and len(rest) > 1:
        return f"{found[0]} {rest[0]} {kind(' '.join(rest[1:]))}"[:60]
    if len(rest) > 1 and rest[0] == "run" and not rest[1].startswith("-"):
        return f"{found[0]} run {os.path.basename(rest[1].rstrip('/')) or rest[1]}"[:60]
    if rest:
        first = rest[0]
        if first.startswith("-"):
            found.append(first.split("=", 1)[0])
            value = rest[1] if len(rest) > 1 and "=" not in first else ""
            if value and not value.startswith("-"):
                if "," in value:
                    found.append(f"[{len([v for v in value.split(',') if v])}]")
                elif len(value) <= 40 and "=" not in value:
                    found.append(os.path.basename(value.rstrip("/")) or value)
        elif "," in first:
            found.append(f"[{len([v for v in first.split(',') if v])}]")
        else:
            found.append(os.path.basename(first.rstrip("/")) or first)
    return " ".join(found)[:60]


def checked_meta(meta) -> dict[str, str]:
    """Lease metadata, validated: raises SlotError for a key that is not a short lowercase word, a value that is
    not short printable text, or too many keys."""
    if meta is None:
        return {}
    if not isinstance(meta, dict):
        raise SlotError("meta must be a mapping of key to value")
    if len(meta) > META_KEYS_MAX:
        raise SlotError(f"at most {META_KEYS_MAX} --meta keys")
    found = {}
    for key, value in meta.items():
        if not isinstance(key, str) or not META_KEY.fullmatch(key):
            raise SlotError(f"--meta key {key!r} must be a lowercase word (a-z, 0-9, _ . -), at most 32 characters")
        if not isinstance(value, str) or len(value) > META_VALUE_MAX or not value.isprintable():
            raise SlotError(f"--meta {key} takes printable text of at most {META_VALUE_MAX} characters")
        if key == "class" and value not in CLASSES:
            raise SlotError(f"the class is one of {', '.join(CLASSES)}, not {value!r}")
        found[key] = value
    return found


def parse_meta(pairs: list[str]) -> dict[str, str]:
    """`key=value` words as lease metadata; a later key replaces an earlier one."""
    found = {}
    for pair in pairs:
        key, equals, value = pair.partition("=")
        if not equals:
            raise SlotError(f"--meta takes key=value, not {pair!r}")
        found[key] = value
    return checked_meta(found)


def meta_of(entry: dict) -> dict[str, str]:
    """An entry's or history line's metadata: {} where it has none (an older client) or it is not a mapping of
    text, as a foreign writer could leave."""
    meta = entry.get("meta")
    if not isinstance(meta, dict):
        return {}
    return {k: str(v) for k, v in meta.items()
            if isinstance(k, str) and META_KEY.fullmatch(k) and isinstance(v, (str, int, float))}


def meta_text(meta: dict) -> str:
    """Metadata for one line: key=value pairs joined by commas, a value quoted where it holds a space, comma, quote
    or equals sign."""
    plain = re.compile(r'[^\s,="]+')
    return ",".join(f"{k}={v if plain.fullmatch(v) else json.dumps(v)}" for k, v in meta.items())


def overtakable(entry: dict, moment: float | None = None) -> bool:
    """Whether later requests that fit may still start before this waiter: it has waited less than the window."""
    queued = seconds(entry.get("since"))
    return queued is not None and (time.time() if moment is None else moment) - queued < overtake_window()


# Ordering: which waiters start now (#643)

def order_settings(directory: Path | None = None, environment: bool = True) -> dict:
    """The queue's order and backfill settings: order.json beside the queue (`slotfather order`), else
    ORDER_DEFAULTS, with "saved" saying which. A client's environment only tightens them: SLOTFATHER_QUEUE=window
    falls back to the window order, a higher SLOTFATHER_BACKFILL_SAFETY or _FALLBACK, a lower _OVERRUN and a lower
    (nonzero) _LIMIT count; looser values are ignored, since every client's look grants for the whole queue. A file
    that cannot be read gives the window order."""
    found = dict(ORDER_DEFAULTS, saved=False)
    try:
        data = json.loads(((directory or state_dir()) / "order.json").read_text())
        found.update(checked_order(data), saved=True)
    except FileNotFoundError:
        pass
    except (OSError, ValueError, TypeError, AttributeError):
        found.update(order="window", saved=True)
    if not environment:  # what every client shares; yield requests are decided on it alone
        return found
    if setting("QUEUE") == "window":
        found["order"] = "window"
    for key, (name, least, tighten) in ORDER_KNOBS.items():
        try:
            value = float(setting(name) or "nan")
        except ValueError:
            continue
        if not math.isfinite(value) or value < least:
            continue
        if tighten == "up":
            found[key] = max(found[key], value)
        elif tighten == "down":
            found[key] = min(found[key], value)
        elif tighten == "delay":  # 0 asks nobody, the tightest
            found[key] = 0.0 if not value or not found[key] else max(found[key], value)
        elif value > 0:  # limit: 0 is no limit, the loosest
            found[key] = value if not found[key] else min(found[key], value)
    return found


def checked_order(data) -> dict:
    """Saved order settings, validated: raises ValueError for anything `slotfather order` would refuse."""
    if not isinstance(data, dict) or set(data) - set(ORDER_DEFAULTS) or data.get("order", "backfill") not in \
            QUEUE_ORDERS:
        raise ValueError(f"not order settings: {data!r}")
    found = {}
    for key, value in data.items():
        if key != "order":
            least = ORDER_KNOBS[key][1]
            if type(value) not in (int, float) or not math.isfinite(value) or value < least:
                raise ValueError(f"{key} must be a number of at least {least:g}, not {value!r}")
        found[key] = value
    return found


def save_order(values: dict | None, directory: Path | None = None) -> None:
    """Publishes order settings for every client (None: back to the defaults); callers hold the queue lock."""
    path = (directory or state_dir()) / "order.json"
    if values is None:
        path.unlink(missing_ok=True)
        return
    values = checked_order({k: v for k, v in values.items() if k in ORDER_DEFAULTS})
    path.parent.mkdir(parents=True, exist_ok=True)
    # The keys before classes always; a class knob only when it differs from its default, since a slotfather before
    # them refuses a file with keys it does not know (and falls back to the window order).
    write(path, {k: values.get(k, ORDER_DEFAULTS[k]) if k == "order" else float(values.get(k, ORDER_DEFAULTS[k]))
                 for k in ORDER_DEFAULTS if k in ORDER_BASE or values.get(k, ORDER_DEFAULTS[k]) != ORDER_DEFAULTS[k]})


def queue_order() -> str:
    """backfill (the default) or window, the order before #643."""
    return order_settings()["order"]


def family(label: str | None) -> str:
    """A label without its ticket or agent id: lane-636-measure and lane-640-smoke-skip are both lane,
    agent-a17b708a4e705e421 is agent, sid-kit-wt-646 is sid-kit-wt."""
    words = (label or "").split("-")
    for at, word in enumerate(words):
        if at and any(c.isdigit() for c in word):
            return "-".join(words[:at])
    return label or ""


class Estimates:
    """Run times of finished requests, for how long a request will run: the median of the last ESTIMATE_RUNS runs
    of the closest kind that ran before (same label and command kind; same label family and command kind; the same
    family with a check list of about the same size; the command kind under any label; about the same size under
    any label; same label; same family), or None for a request like nothing before."""

    def __init__(self, runs=()):
        self.runs = {}
        for label, command, ran in runs:
            self.add(label, command, ran)

    @staticmethod
    def keys(label: str | None, command: str | None) -> list[tuple]:
        found = []
        if command:
            what = kind(command)
            # A list of checks keeps its size within a factor of two: 140 checks are not 4.
            rough = re.sub(r" \[(\d+)\]$", lambda m: f" [~{int(m[1]).bit_length()}]", what)
            found += [("label", label, what), ("family", family(label), what), ("family", family(label), rough),
                      ("kind", what), ("rough", rough)]
        return found + [("label", label), ("family", family(label))]

    def add(self, label: str | None, command: str | None, ran: float) -> None:
        for key in self.keys(label, command):
            recent = self.runs.setdefault(key, [])
            recent.append(float(ran))
            del recent[:-ESTIMATE_RUNS]

    def save(self) -> dict:
        return {json.dumps(key): runs for key, runs in self.runs.items()}

    @classmethod
    def load(cls, saved: dict) -> "Estimates":
        found = cls()
        found.runs = {tuple(json.loads(key)): [float(v) for v in runs] for key, runs in saved.items()}
        return found

    def of(self, label: str | None, command: str | None) -> float | None:
        for key in self.keys(label, command):
            recent = self.runs.get(key)
            if recent:
                ordered = sorted(recent)
                middle = len(ordered) // 2
                return ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2
        return None


def history_estimates(directory: Path) -> Estimates:
    """Estimates from the end of history.jsonl (ESTIMATE_BYTES of it): every request that was granted and ran to its
    release. A reaped lease is left out: its holder died, and its time runs to whenever a look noticed, such as an
    orphan of a hung CI job that kept its slots for most of an hour; so is one that gave up (`left`). Requests whose
    holder ran a slotfather that records no history (before #635) are not in it."""
    path = directory / "history.jsonl"
    runs = []
    for part in (path.with_name(path.name + ".1"), path):
        try:
            with open(part, "rb") as handle:
                end = handle.seek(0, os.SEEK_END)
                handle.seek(max(0, end - ESTIMATE_BYTES))
                lines = handle.read().splitlines()
        except FileNotFoundError:
            continue
        for item in objects(lines[1:] if end > ESTIMATE_BYTES else lines):
            if isinstance(item.get("ran"), (int, float)) and item.get("granted") and \
                    item.get("outcome") not in UNFINISHED:
                runs.append((item.get("label"), item.get("cmd"), item["ran"]))
    return Estimates(runs)


def class_of(entry: dict) -> str:
    """interactive, normal or batch: the entry's metadata `class`, normal when it has none or another word."""
    value = meta_of(entry).get("class")
    return value if value in CLASSES else "normal"


def rank_time(entry: dict, settings: dict) -> float:
    """When a waiter counts as queued: an interactive one `interactive` seconds before it came, a batch one `batch`
    seconds after. The offset is its ageing: a batch request that has waited longer than the two together is ahead
    of every interactive one that comes after. A lease that yielded counts as queued at its pinned `rank`, just
    behind the waiter it yielded to, whatever its class: it is half done and holds its memory meanwhile."""
    behind = entry.get("rank")  # a lease that yielded queues just behind the waiter it yielded to, and only there
    if type(behind) in (int, float) and math.isfinite(behind):
        return float(behind)
    queued = seconds(entry.get("since"))
    queued = math.inf if queued is None else queued
    cls = class_of(entry)
    return queued - settings.get("interactive", 0.0) if cls == "interactive" else \
        queued + settings.get("batch", 0.0) if cls == "batch" else queued


def ranked(waiters: list[dict], settings: dict) -> list[dict]:
    """Waiters in the order the queue serves them: by rank_time(), then as they came (a stable sort)."""
    return sorted(waiters, key=lambda entry: rank_time(entry, settings))


class Plan:
    """What grant() does to the waiters: `grants` start now, in queue order; `reason` says why the first that does
    not start waits; `head` is the waiter the others must not delay, expected to start at `start` (epoch seconds)."""

    def __init__(self):
        self.grants, self.reason, self.head, self.start = [], None, None, None


def reserve(found: Plan, held: list[dict], slots: int, used: int, moment: float, estimate, fallback: float,
            overrun: float) -> int:
    """Sets the head's expected start: when, by the expected ends of what holds slots (`held` and the grants so
    far), enough slots will be free for it. Returns the slots spare then, those the head will not need even if the
    leases expected to run on past its start are the largest ones (estimates are rough, and which lease ends first
    is too)."""
    ends = []
    for entry in held + found.grants:
        granted = seconds(entry.get("granted"))
        ran = 0.0 if granted is None else max(0.0, moment - granted - float(entry.get("yielded") or 0))
        run = estimate(entry)
        run = fallback if run is None else run
        ends.append((moment + max(run - ran, overrun * ran), entry["count"]))
    have, found.start = max(0, slots - used), moment
    for end, count in sorted(ends):
        if have >= found.head["count"]:
            break
        have, found.start = have + count, end
    if have < found.head["count"]:  # slots held in an earlier queue, whose end is unknown: nothing passes
        found.start = moment
        return 0
    staying = sum(1 for end, _ in ends if end > found.start)
    largest = sum(sorted((count for _, count in ends), reverse=True)[:staying])
    other = used - sum(count for _, count in ends)  # held in an earlier queue
    return max(0, min(have, slots - other - largest) - found.head["count"])


def soonest_start(count: int, holding: list[dict], slots: int, used: int, moment: float, estimate) -> float | None:
    """The earliest moment `count` slots can be free if each lease in `holding` ends when its expected run does,
    with no overrun (one past its expected run may end any moment). None when that is unknown: a lease whose run
    the history does not know (it may end any moment too), or slots held in an earlier queue. reserve() is the
    cautious counterpart, for what may pass a head; this one is for whether a waiter can start at all before its
    client gives up."""
    ends = []
    for entry in holding:
        run = estimate(entry)
        if run is None:
            return None
        granted = seconds(entry.get("granted"))
        ran = 0.0 if granted is None else max(0.0, moment - granted - float(entry.get("yielded") or 0))
        ends.append((moment + max(0.0, run - ran), entry["count"]))
    have, start = max(0, slots - used), moment
    for end, size in sorted(ends):
        if have >= count:
            break
        have, start = have + size, end
    return start if have >= count else None


def fit(waiters: list[dict], slots: int) -> list[dict]:
    """Makes each waiter ask for at most the capacity `slots`, and an `-n all` one (its entry's `all`) for exactly
    it: a capacity that shrank under a waiter (a memory budget when a VM's balloon takes memory) would otherwise
    leave it waiting for slots that no longer exist. The change is the waiter's own entry's: a grant writes it and
    the holder takes its count from there. Only for the queue's whole capacity, not a share of it."""
    for entry in waiters:
        if entry.get("all") or entry["count"] > slots:
            entry["count"] = slots
    return waiters


def plan(waiters: list[dict], held: list[dict], slots: int, moment: float, order: str | None = None,
         estimate=None, other: int = 0, reserve_head: bool = False, settings: dict | None = None) -> Plan:
    """Which of `waiters` (queue order) start now beside `held` (entries; `other` slots more held without one) on
    `slots` slots at epoch `moment`. `estimate(entry)` is its expected run in seconds or None (unknown).

    window: in arrival order; a waiter that does not fit lets later ones that fit start first until it has waited
    SLOTFATHER_OVERTAKE_WINDOW, then holds back everyone behind it.

    backfill: waiters in their class order (ranked(): an interactive one `interactive` seconds earlier than it came,
    a batch one `batch` seconds later, a yielded lease just behind the waiter it yielded to); the same within the
    window; the first waiter past it that does not fit is the head. Its start is
    reserved: the moment enough slots will be free, from the expected ends of the held leases. Until the head has
    waited `limit` seconds, a later waiter that fits starts before it when `safety` times its expected run ends by
    the head's start and by that limit, or when it takes only slots the head will not need then (reserve()); past
    the limit nothing passes. An unknown run counts `fallback` seconds; a held lease past its expected run is
    expected to run on for `overrun` times what it has run so far. A waiter whose client gives up (its entry's
    `until`, from `run --wait`) before it has waited `limit` and before even the held leases' expected runs,
    without overrun, free its slots (soonest_start(); unknown runs keep it the head) is no head: it would leave
    without running, so it holds nobody back. `settings` are order_settings() unless given; `order` overrides
    theirs. The head's start is worked out only when a request behind it fits, or with `reserve_head`."""
    settings = settings or order_settings()
    order = order or settings["order"]
    estimate = estimate or (lambda entry: None)
    window = overtake_window()
    if order == "backfill":
        waiters = ranked(waiters, settings)
    fallback, safety, overrun, limit = (settings[key] for key in ("fallback", "safety", "overrun", "limit"))
    found = Plan()
    used = sum(e["count"] for e in held) + other
    extra = None  # slots free at the head's start that it does not need; reserved once a request behind it fits
    for entry in waiters:
        free = max(0, slots - used)
        if found.head is not None:
            if entry["count"] > free:
                continue
            if extra is None:
                extra = reserve(found, held, slots, used, moment, estimate, fallback, overrun)
            # A yielded head counts its limit from when it yielded: by its arrival the limit is long past.
            began = epoch(found.head.get("yielded_at")) or seconds(found.head.get("since")) or moment
            deadline = began + limit if limit else math.inf
            if moment >= deadline:
                continue  # the head has waited the limit: it holds back everyone behind it
            run = estimate(entry)
            run = fallback if run is None else run
            if moment + run * safety <= min(found.start, deadline):
                pass  # ends before the head can start, and before it has waited the limit
            elif entry["count"] <= extra:
                extra -= entry["count"]
            else:
                continue
            found.grants.append(entry)
            used += entry["count"]
            continue
        if entry["count"] <= free:
            found.grants.append(entry)
            used += entry["count"]
            continue
        queued = seconds(entry.get("since"))
        passable = queued is not None and moment - queued < window
        if order != "backfill":
            if not passable:
                found.reason = found.reason or f"{free} of {slots} slots free"
                return found
        elif not passable:
            found.head = entry
            gives_up = None if entry.get("granted") else seconds(entry.get("until"))
            began = seconds(entry.get("since"))
            if gives_up is not None and began is not None and (not limit or moment < began + limit):
                soonest = soonest_start(entry["count"], held + found.grants, slots, used, moment, estimate)
                if soonest is not None and soonest > gives_up:
                    # Its client gives up before the slots it needs can be free even if every held lease ends
                    # when its kind usually does: holding the others back would only leave slots idle until it
                    # leaves without running. Past its limit it is the head whatever its wait, as before.
                    found.head = None
                    clock = time.strftime("%H:%M:%S", time.localtime(gives_up))
                    found.reason = found.reason or (f"{free} of {slots} slots free; {entry['label']} gives up at "
                                                    f"{clock}, before they are expected, so requests that fit pass it")
                    continue
            found.reason = (f"{free} of {slots} slots free; {entry['label']} is next, and a later request that fits "
                            f"starts first only if it ends before {entry['label']} can start")
            if reserve_head:
                extra = reserve(found, held, slots, used, moment, estimate, fallback, overrun)
            continue
        until = time.strftime("%H:%M:%S", time.localtime(queued + window))
        found.reason = found.reason or (f"{free} of {slots} slots free; requests that fit may pass "
                                        f"{entry['label']} until {until}")
    return found


def yield_asks(waiters: list[dict], held: list[dict], slots: int, moment: float, estimate=None, other: int = 0,
               settings: dict | None = None, asked=()) -> list[tuple[dict, dict]]:
    """Polite preemption (#643): (holder, waiter) pairs, the holders of `held` (entries, after this look's grants)
    that a waiter asks to yield now. Only an interactive waiter asks, once it has waited `yield_after` seconds, does
    not fit, and would not get its slots within `yield_after` by the held leases' expected ends; it asks only
    holders that opted in (`yieldable`), are of a lower class, have held their slots `yield_after` seconds since
    their last grant and were asked fewer than YIELDS_MAX times, and only as many as it needs (holders in `asked`,
    their ids, first; then the lowest class; then the one expected to run longest), and only when grant() would
    then start it, with the asked holders back among the waiters at their own rank. Nobody is ever stopped: a
    holder yields when its client gets round to it, or not at all."""
    settings = settings or order_settings()
    after = settings.get("yield_after") or 0
    if not after or settings["order"] != "backfill":
        return []
    estimate = estimate or (lambda entry: None)
    level = {name: n for n, name in enumerate(CLASSES)}
    asked_ids = {id(entry) for entry in asked}
    holding, found, granted = list(held), [], []

    def expected_end(entry):
        began = seconds(entry.get("granted"))
        ran = 0.0 if began is None else max(0.0, moment - began - float(entry.get("yielded") or 0))
        run = estimate(entry)
        run = settings["fallback"] if run is None else run
        return moment + max(run - ran, settings["overrun"] * ran)

    for entry in ranked(waiters, settings):
        if class_of(entry) not in ASKERS or any(entry is g for g in granted):
            continue
        own = entry.get("yield_after")  # its client's environment asks later, or never (0)
        wait_for = max(after, float(own)) if type(own) in (int, float) and own > 0 else \
            None if type(own) in (int, float) else after
        queued = seconds(entry.get("since"))
        if wait_for is None or queued is None or moment - queued < wait_for:
            continue
        free = slots - other - sum(h["count"] for h in holding)
        if entry["count"] <= free:
            continue  # it fits: what holds it back is not slots
        have, when = free, moment
        for end, count in sorted((expected_end(h), h["count"]) for h in holding):
            if have >= entry["count"]:
                break
            have, when = have + count, end
        if have >= entry["count"] and when - moment <= after:
            continue  # its slots are expected soon anyway
        candidates = [h for h in holding if h.get("yieldable") and level[class_of(h)] > level[class_of(entry)]
                      and int(h.get("yields") or 0) < YIELDS_MAX
                      and moment - (seconds(h.get("resumed") or h.get("granted")) or moment) >= after]
        candidates.sort(key=lambda h: (id(h) not in asked_ids, -level[class_of(h)], -expected_end(h)))
        chosen, need = [], entry["count"] - free
        for h in candidates:
            if need <= 0:
                break
            chosen.append(h)
            need -= h["count"]
        if need > 0:
            continue
        behind = rank_time(entry, settings) + YIELD_BEHIND
        back = [dict(h, state="waiting", rank=behind) for h in chosen]
        rest = [w for w in waiters if not any(w is g for g in granted)] + back
        trial = plan(rest, [h for h in holding if not any(h is c for c in chosen)], slots, moment, estimate=estimate,
                     other=other, settings=settings)
        if not any(g is entry for g in trial.grants):
            continue
        found += [(h, entry) for h in chosen]
        holding = [h for h in holding if not any(h is c for c in chosen)] + [entry]
        granted.append(entry)
    return found


def room(waiters: list[dict], free: int, held: list[dict] | None = None, estimate=None, other: int = 0,
         settings: dict | None = None, label: str = "", command: str = "") -> int:
    """The slots a new request gets at once behind `waiters` with `free` slots unheld, as grant() admits it: one
    for `command` under `label`, whose run the estimates know, or else one of unknown run (the fallback). Without
    `held` (the entries holding slots; `other` slots more held without one), the window order's answer."""
    slots = free + sum(e["count"] for e in held or ()) + other
    if held is not None:  # the whole capacity: what grant() fits the waiters to
        fit(waiters, slots)
    moment = time.time()
    settings = settings or order_settings()
    order = settings["order"] if held is not None else "window"
    for count in range(free, 0, -1):
        probe = {"count": count, "label": label, "cmd": command, "since": now()}
        if any(entry is probe for entry in plan(waiters + [probe], held or [], slots, moment, order, estimate,
                                                         other, settings=settings).grants):
            return count
    return 0


_estimates = {}  # history files' (size, mtime) -> Estimates, so a waiter's repeated looks read the history once


def cached_estimates(directory: Path) -> Estimates:
    """history_estimates(), kept in this process and in estimates.json beside the history, both keyed by the
    history files' size and modification time: a new process, a release or `available` reads the small file
    instead of the history until the history changes. A file another version wrote (its "v" differs) is worked out
    again, so runs that version counted (reaped leases, before version 2) do not linger until the history changes;
    an older client reads past the "v"."""
    path = directory / "history.jsonl"
    stamp = []
    for part in (path.with_name(path.name + ".1"), path):
        with contextlib.suppress(OSError):
            info = part.stat()
            stamp.append([part.name, info.st_size, info.st_mtime_ns])
    key = json.dumps(stamp)
    if key in _estimates:
        return _estimates[key]
    cache = directory / "estimates.json"
    found = None
    with contextlib.suppress(OSError, ValueError, TypeError, AttributeError, KeyError):
        saved = json.loads(cache.read_text())
        if saved["stamp"] == stamp and saved.get("v") == ESTIMATES_VERSION:
            found = Estimates.load(saved["runs"])
    if found is None:
        found = history_estimates(directory)
        if foreign_owner(directory) is None:
            with contextlib.suppress(OSError):
                write(cache, {"v": ESTIMATES_VERSION, "stamp": stamp, "runs": found.save()})
    _estimates.clear()
    _estimates[key] = found
    return found


def estimator(directory: Path):
    """estimate(entry) from cached_estimates(), read only when plan() first asks (a head waits and a later
    request fits)."""
    def estimate(entry: dict) -> float | None:
        return cached_estimates(directory).of(entry.get("label"), entry.get("cmd"))
    return estimate


# Polite preemption (#643): a holder that opted in (`run --yieldable`) is asked to yield by a marker file beside its
# entry, <entry>.yield, which its client checks between steps; it yields with `slotfather yield` (or
# Lease.yield_slots()), which puts it back among the waiters just behind the waiter that asked and returns once the
# lease is granted again. Nothing else ever happens to a holder that does not.

def marker(path: Path) -> Path:
    """The yield request beside a queue entry (SLOTFATHER_YIELD in a yieldable lease's command)."""
    return path.with_suffix(".yield")


def asked(path: Path) -> dict | None:
    """The yield request for the entry at `path`, or None."""
    try:
        found = json.loads(marker(path).read_text())
    except (OSError, ValueError):
        return None
    return found if isinstance(found, dict) else None


def epoch(value) -> float | None:
    """A moment stored as epoch seconds or as a now() stamp, as epoch seconds; None for anything else."""
    return float(value) if type(value) in (int, float) and math.isfinite(value) else seconds(value)


def resume(entry: dict, moment: float | None = None) -> None:
    """A yielded lease that was granted again (at `moment`, else its `granted` stamp): `granted` is its first grant
    again (waits and runs in the history stay its own), `resumed` this grant, `yielded` the seconds it spent back in
    the queue."""
    away = epoch(entry.get("yielded_at"))
    if away is None:
        return
    again = entry.get("granted")
    back = moment if moment is not None else seconds(again) or time.time()
    entry["yielded"] = round(float(entry.get("yielded") or 0) + max(0.0, back - away), 2)
    entry.update(resumed=again, granted=entry.get("first_granted") or again)
    for key in ("yielded_at", "first_granted", "rank"):
        entry.pop(key, None)


def ask(directory: Path, live: list[tuple[Path, dict]], held: list[dict], waiters: list[dict],
        estimate, other: int, settings: dict) -> None:
    """Writes the yield requests yield_asks() wants and withdraws the others. Under the queue lock. `settings` are
    the saved ones without this client's environment, so that every client's look asks alike (a waiter whose
    client asks later or never says so on its entry)."""
    paths = {id(e): path for path, e in live}
    wanted = yield_asks(waiters, held, total(), time.time(), estimate, other, settings,
                        asked=[e for e in held if marker(paths[id(e)]).exists()])
    asks = {id(h): w for h, w in wanted}
    for path, entry in live:
        place = marker(path)
        if id(entry) in asks:
            who = asks[id(entry)]
            if place.exists():
                continue
            write(place, {"by": paths[id(who)].stem, "label": who.get("label"), "class": class_of(who),
                          "count": who["count"], "at": now()})
            log(directory, f"asked {entry['label']} (pid {entry['pid']}) to yield {entry['count']} for "
                           f"{who.get('label')}")
        elif place.exists():
            place.unlink(missing_ok=True)
            log(directory, f"withdrew the yield request to {entry['label']} (pid {entry['pid']})")
    for place in (directory / "queue").glob("*.yield"):  # requests left by entries gone meanwhile
        if not place.with_suffix(".json").exists():
            place.unlink(missing_ok=True)


def yield_lease(path: Path, out=sys.stderr) -> bool:
    """Yields the held lease at `path` if it was asked to and the waiter that asked still waits: the lease goes back
    among the waiters just behind that waiter, the queue grants at once, and this returns True when the lease is
    held again. Returns False at once when nothing asked."""
    directory = path.parent.parent
    with locked(directory):
        try:
            entry = json.loads(path.read_text())
        except (OSError, ValueError):
            raise SlotError("the lease vanished from the queue") from None
        request = asked(path)
        if entry.get("state") != "held" or request is None:
            return False
        live = reap(directory, processes())
        asker = next((e for p, e in live if p.stem == request.get("by") and e.get("state") != "held"), None)
        settings = order_settings(directory, environment=False)
        behind = rank_time(asker, settings) + YIELD_BEHIND if asker is not None else None
        if asker is not None:  # would the asker start? Things may have changed since it asked.
            table = processes()
            held = [e for p, e in live if e.get("state") == "held" and p != path]
            waiters = [e for p, e in live if e.get("state") != "held"] + [dict(entry, state="waiting", rank=behind)]
            trial = plan(waiters, held, total(), time.time(), estimate=estimator(directory),
                         other=legacy_used(table), settings=settings)
            if not any(e is asker for e in trial.grants):
                asker = None
        if asker is None:  # it started, left or would still not start; the next look would withdraw the request
            marker(path).unlink(missing_ok=True)
            log(directory, f"withdrew the yield request to {entry.get('label')} (pid {entry.get('pid')})")
            return False
        entry.update(state="waiting", yields=int(entry.get("yields") or 0) + 1, yielded_at=round(time.time(), 3),
                     first_granted=entry.get("granted"), rank=behind)
        write(path, entry)
        marker(path).unlink(missing_ok=True)
        log(directory, f"yielded {entry['count']} ({path.name}) to {asker.get('label')}")
        grant(directory, processes())
    print(f"slot: {entry.get('label')} yielded {entry['count']} slot(s) to {asker.get('label')}; it resumes when "
          f"they are free", file=out, flush=True)
    held_again(path)
    print(f"slot: {entry.get('label')} resumes with {entry['count']} slot(s)", file=out, flush=True)
    return True


def held_again(path: Path) -> None:
    """Waits until the yielded lease at `path` is granted again, looking at the queue as a waiter does."""
    directory = path.parent.parent
    poll = float(setting("POLL") or 2)
    poll_max = max(poll, float(setting("POLL_MAX") or POLL_MAX))
    interval, look = poll, 0.0
    while True:
        if time.monotonic() >= look:
            with locked(directory):
                grant(directory, processes())
                try:
                    entry = json.loads(path.read_text())
                except (OSError, ValueError):
                    raise SlotError("the lease vanished from the queue") from None
                if entry.get("state") == "held":
                    if "yielded_at" in entry:  # an older client granted it
                        resume(entry)
                        write(path, entry)
                    return
            interval = min(interval * 1.5, poll_max)
            look = time.monotonic() + interval
        try:
            if json.loads(path.read_text()).get("state") == "held":
                look = 0.0  # held: settle it under the lock at once
                continue
        except (OSError, ValueError):
            raise SlotError("the lease vanished from the queue") from None
        time.sleep(min(poll, max(0.0, look - time.monotonic())))


def grant(directory: Path, table: dict) -> str | None:
    """Grant the waiters plan() starts, in their order, while memory allows; then ask yieldable holders to yield for
    interactive waiters that still wait (yield_asks()). Returns why the first that does not start still waits."""
    live = reap(directory, table)
    held = [e for _, e in live if e["state"] == "held"]
    waiters = [e for _, e in live if e["state"] != "held"]
    paths = {id(e): path for path, e in live}
    estimate = estimator(directory)
    other = legacy_used(table)
    slots = total()
    found = plan(fit(waiters, slots), held, slots, time.time(), estimate=estimate, other=other,
                 settings=order_settings(directory))
    used = sum(e["count"] for e in held) + other
    short = None
    for entry in found.grants:
        if used:
            short = short or memory_short()
            if short:
                return short
        entry.update(state="held", granted=now())
        resume(entry, time.time())
        write(paths[id(entry)], entry)
        used += entry["count"]
        log(directory, f"granted {entry['count']} to {entry['label']} (pid {entry['pid']})")
    rest = [e for e in waiters if not any(e is g for g in found.grants)]
    with contextlib.suppress(OSError, SlotError):
        ask(directory, live, held + found.grants, rest, estimate, other, order_settings(directory, environment=False))
    return found.reason


def log(directory: Path, message: str) -> None:
    with contextlib.suppress(OSError):
        with open(directory / "queue.log", "a", encoding="utf-8") as handle:
            handle.write(f"{now()} {message}\n")


def snapshot(directory: Path | None = None) -> tuple[list[dict], list[tuple[Path, dict, int]], dict]:
    """The live queue entries, the earlier queues' holders and the process table."""
    directory = directory or state_dir()
    table = processes()
    with locked(directory):
        live = [entry for _, entry in reap(directory, table)]
    return live, legacy_holders(table), table


def status_lines(directory: Path | None = None) -> list[str]:
    directory = directory or state_dir()
    table = processes()
    with locked(directory):
        live = reap(directory, table)
    legacy = legacy_holders(table)
    lines = []
    for path, e in live:
        meta = meta_of(e)
        tags = f" meta={meta_text(meta)}" if meta else ""
        if e.get("yieldable"):
            request = asked(path) if e.get("state") == "held" else None
            tags += " yieldable" + (f" asked-to-yield-for={request.get('label')}" if request else "") + \
                (f" yielded={e['yields']}" if e.get("yields") else "")
        lines.append(f"{e['state']}: {e['count']} slot(s) {e['label']} pid={e['pid']} since={e['since']}{tags} "
                     f"cmd={e['cmd']}")
    lines += [f"legacy: {count} slot(s) {e.get('label')} pid={e.get('pid')} (earlier queue {path.parent.parent})"
              for path, e, count in legacy]
    used = sum(e["count"] for _, e in live if e["state"] == "held") + sum(count for _, _, count in legacy)
    return lines + [f"{used} of {total()} slots held"]


def process_group(pid) -> int | None:
    try:
        return os.getpgid(pid)
    except (OSError, TypeError):
        return None


def descendants(table: dict, pid) -> list[int]:
    """`pid` and its live descendants, from a processes() table; [] when `pid` is not live."""
    if pid not in table:
        return []
    children = {}
    for child, (parent, _) in table.items():
        children.setdefault(parent, []).append(child)
    found, stack = [], [pid]
    while stack:
        here = stack.pop()
        if here not in found:
            found.append(here)
            stack.extend(children.get(here, ()))
    return sorted(found)


def status_json(directory: Path | None = None, pid: int | None = None) -> dict:
    """The queue for programs (`status --json`): every live entry with its lease id (the entry's name), the lease
    path (what SLOTFATHER_LEASE holds), holder pid and process group, its live process tree and its metadata. With
    `pid`, only the entries that process belongs to, each with `via`: "tree" (the holder or a descendant) or "env"
    (it left the tree, by a double fork or setsid and launchd adopting it, but its environment carries the lease's
    SLOTFATHER_LEASE; macOS shows that only for the user's own processes that are not Apple platform binaries), and
    `query`: the pid and its start time as `ps -o lstart=` gives it (None: not running), for a guard to check again
    that it is the same process before it acts."""
    directory = directory or state_dir()
    table = processes()
    with locked(directory):
        live = reap(directory, table)
    entries_found = []
    for path, entry in live:
        tree = descendants(table, entry.get("pid"))
        item = {"id": path.stem, "lease": str(path), "state": entry.get("state"), "count": entry.get("count"),
                "label": entry.get("label"), "pid": entry.get("pid"), "pgid": process_group(entry.get("pid")),
                "start": entry.get("start"), "since": entry.get("since"), "granted": entry.get("granted"),
                "cmd": entry.get("cmd"), "cwd": entry.get("cwd"), "meta": meta_of(entry), "tree": tree,
                "class": class_of(entry), "yieldable": bool(entry.get("yieldable")),
                "yields": int(entry.get("yields") or 0), "yield_asked": asked(path), "position": None}
        entries_found.append(item)
    settings = order_settings(directory)
    serving = ranked([e for _, e in live if e.get("state") != "held"], settings) \
        if settings["order"] == "backfill" else [e for _, e in live if e.get("state") != "held"]
    places = {id(e): n for n, e in enumerate(serving, 1)}
    for (path, entry), item in zip(live, entries_found):
        item["position"] = places.get(id(entry))  # waiters: their place in the order the queue serves them
    legacy = []
    for path, entry, count in legacy_holders(table):
        legacy.append({"id": path.stem, "lease": str(path), "state": "held", "count": count,
                       "label": entry.get("label"), "pid": entry.get("pid"), "pgid": process_group(entry.get("pid")),
                       "tree": descendants(table, entry.get("pid"))})
    held = sum(e["count"] for e in entries_found if e["state"] == "held") + sum(e["count"] for e in legacy)
    found = {}
    if pid is not None:
        mine = []
        for item in entries_found:
            if pid in item["tree"]:
                mine.append(dict(item, via="tree"))
            elif pid in table and carrying([pid], item["lease"]):
                mine.append(dict(item, via="env"))
        entries_found = mine
        legacy = [dict(e, via="tree") for e in legacy if pid in e["tree"]]
        found["query"] = {"pid": pid, "start": table[pid][1] if pid in table else None}
    slots = total()
    return {"v": 1, "slots": slots, "held": held, "free": max(0, slots - held), "entries": entries_found,
            "legacy": legacy, **found}


def available(directory: Path | None = None, label: str = "", command: str = "") -> int:
    """How many slots a new request would get at once: the free ones less what waiters take first, or none while a
    waiter past the overtaking window holds back everyone behind it, unless (backfill) the request is expected to
    end before that waiter can start. Without `command` its run counts as unknown (the fallback)."""
    directory = directory or state_dir()
    live, legacy, _ = snapshot(directory)
    held = [e for e in live if e["state"] == "held"]
    other = sum(count for _, _, count in legacy)
    return room([e for e in live if e["state"] != "held"], max(0, total() - sum(e["count"] for e in held) - other),
                held, estimator(directory), other, label=label, command=command)


# Sizing

def size(maximum: int, cores: int, total: int, averages: tuple[float, float, float], held: int,
         waiting: bool = False, exclusive: bool = False) -> dict:
    """A job count for work that runs beside `held` leased slots (or after them, when `exclusive`) under load
    `averages` (1, 5 and 15 minutes) that include processes taking no lease. The module docstring has the formula."""
    per_slot = cores / total
    load1, load5, load15 = averages
    load = min(load1, load5)
    unleased = max(0.0, load - held * per_slot)
    busy = unleased + (0.0 if exclusive else held * per_slot)
    capacity = max(0, math.floor((cores - busy) / per_slot + 0.5))
    free = total if exclusive else 0 if waiting else max(0, total - held)
    jobs = max(1, min(maximum, capacity, free))
    return {"jobs": jobs, "maximum": maximum, "exclusive": exclusive, "cores": cores, "total": total,
            "cores_per_slot": round(per_slot, 2), "held": held, "waiting": waiting, "free": free,
            "load": round(load, 2), "load1": round(load1, 2), "load5": round(load5, 2), "load15": round(load15, 2),
            "unleased_load": round(unleased, 2), "capacity": capacity}


def advise(maximum: int | None = None, exclusive: bool = False, cores_now: int | None = None,
           averages: tuple[float, float, float] | None = None, label: str = "", command: str = "") -> dict:
    """size() for the queue as it is now: slots held by others (the caller's own lease is not one) and
    whether a request waits, a request for `command` under `label` when given (else one of unknown run), with
    "run_estimate", the run the history expects of it (None: unknown, counted as the fallback)."""
    live, legacy, table = snapshot()
    mine = inherited_lease(table)
    holders = [e for e in live if e["state"] == "held" and not (mine and e["pid"] == mine[1]["pid"])]
    other = sum(count for path, e, count in legacy if not (mine and path == mine[0]))
    held = sum(e["count"] for e in holders) + other
    basis = capacity_basis()
    slots = basis["slots"]
    waiters = [e for e in live if e["state"] != "held"]
    estimate = estimator(state_dir())
    waiting = bool(waiters) and room(waiters, max(0, slots - held), holders, estimate, other, label=label,
                                     command=command) == 0
    found = size(maximum or slots, cores_now or cores(), slots, averages or loads(), min(held, slots), waiting,
                 exclusive)
    found["run_estimate"] = estimate({"label": label, "cmd": command}) if command else None
    # How the capacity was found (#653), and why new leases would wait for memory now (None: they would not); the
    # job count does not shrink for it: a caller that starts memory-heavy workers should.
    found.update(capacity_mode=basis["mode"], gib_per_slot=basis["gib_per_slot"], memory_gib=basis["memory_gib"],
                 memory_short=memory_short())
    return found


# Leases

class Lease:
    """A held lease, an inherited one, or none (bypass). Release it once the work has finished."""

    def __init__(self, count: int, path: Path | None = None, inherited: bool = False, yieldable: bool = False):
        self.count, self.path, self.inherited, self.yieldable = count, path, inherited, yieldable
        self.status = None  # the command's exit status, for the history, where the holder knows it
        self.usage = None  # what the command's process tree used (TreeUsage.result), where the holder measured it

    def environment(self) -> dict[str, str]:
        if self.path is None:
            return {}
        env = {}
        for prefix in LEASE_ENV_PREFIXES:
            env.update({prefix + "LEASE": str(self.path), prefix + "COUNT": str(self.count)})
            if self.yieldable and not self.inherited:
                env[prefix + "YIELD"] = str(marker(self.path))
        return env

    def yield_requested(self) -> dict | None:
        """The yield request for this lease, or None: {"by", "label", "class", "count", "at"} of the waiter that
        asked. Cheap (one stat and a small read); call it between steps."""
        return None if self.path is None or self.inherited else asked(self.path)

    def yield_slots(self, out=sys.stderr) -> bool:
        """Yields the lease if it was asked to: back among the waiters, just behind the waiter that asked, until it is
        granted again; returns True then, False at once when nothing asked (or the asker no longer waits). Call it
        only between steps, with none of the lease's own work running."""
        if self.path is None or self.inherited:
            return False
        return yield_lease(self.path, out=out)

    def release(self) -> None:
        if self.path is not None and not self.inherited:
            directory = self.path.parent.parent
            with locked(directory):
                try:
                    entry = json.loads(self.path.read_text())
                except (OSError, ValueError):
                    entry = None
                self.path.unlink(missing_ok=True)
                log(directory, f"released {self.count} ({self.path.name})")
                marker(self.path).unlink(missing_ok=True)
                if isinstance(entry, dict):
                    ran = entry.get("state") == "held" or bool(entry.get("yields"))  # a yielded lease ran
                    record(directory, entry, "released" if ran else "left", self.status, self.usage)
                # Hand the slots on now: waiters look at the queue less often the longer they wait.
                with contextlib.suppress(SlotError, OSError):
                    grant(directory, processes())
            self.path = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.release()


def inherited_lease(table: dict) -> tuple[Path, dict, int] | None:
    """The held lease this process runs under, here or in an earlier queue: (path, entry, slots here)."""
    mine = ancestors(table, os.getpid())
    own = setting("LEASE")
    for path, entry in entries(state_dir()):
        mine_now = entry.get("state") == "held" or "yielded_at" in entry  # a yielded lease is still this tree's
        if mine_now and alive(entry, table) and (own == str(path) or entry["pid"] in mine):
            return path, entry, entry["count"]
    for path, entry, count in legacy_holders(table):
        if own == str(path) or entry["pid"] in mine:
            return path, entry, count
    return None


def inherited(table: dict) -> Lease | None:
    found = inherited_lease(table)
    if found is None:
        return None
    path, entry, count = found
    if "yielded_at" in entry:
        held_again(path)  # it yielded: what runs under it waits until it is granted again
    # A lease in an earlier queue is honoured but not handed on: nested runs find its holder among their ancestors.
    return Lease(count, path if path.parent.parent == state_dir() else None, inherited=True)


def policy() -> str:
    value = setting("POLICY") or "normal"
    if value not in POLICIES:
        raise SlotError(f"invalid SLOTFATHER_POLICY {value!r}: use {', '.join(POLICIES)}")
    return value


def acquire(count: int | str, label: str, command: str = "", out=sys.stderr, wait: float | None = None,
            note: str = "", meta: dict | None = None, yieldable: bool = False) -> Lease:
    """Wait in the queue for `count` slots (at most the total); the lease is held by this process until released.
    Raises SlotTimeout, having left the queue, when `wait` seconds pass first. `note` follows the first word that
    the request waits. `meta` (key -> text) goes on the queue entry and the history line; a process that inherits
    a lease keeps that lease's metadata and adds none. A `yieldable` lease may be asked to yield for interactive
    waiters (see Lease.yield_slots(); the README's client protocol); it never is otherwise."""
    if count != "all" and (type(count) is not int or count < 1):
        raise SlotError("count must be a positive integer or all")
    meta = checked_meta(meta)
    if policy() == "bypass":
        return Lease(total())
    directory = state_dir()
    table = processes()
    found = inherited(table)
    if found:
        return found
    poll = float(setting("POLL") or 2)
    poll_max = max(poll, float(setting("POLL_MAX") or POLL_MAX))
    me = os.getpid()
    try:
        cwd = os.getcwd()
    except OSError:
        cwd = ""
    require_own(directory, "a lease")
    with locked(directory):
        # Admission and capacity changes share this lock; resolve all only now (and again at the grant: plan()).
        whole = count == "all"
        count = total() if whole else min(count, total())
        sequence_file = directory / "sequence"
        try:
            sequence = int(sequence_file.read_text() or 0) + 1
        except (OSError, ValueError):
            sequence = 1
        sequence_file.write_text(str(sequence))
        path = directory / "queue" / f"{sequence:010d}-{me}.json"
        entry = {"pid": me, "start": table.get(me, (0, ""))[1], "count": count, "label": label, "cmd": command,
                 "cwd": cwd, "since": now(), "state": "waiting"}
        if whole:
            entry["all"] = True  # the capacity at the grant; older clients read past fields they do not know
        if meta:
            entry["meta"] = meta  # older clients read past fields they do not know
        if yieldable:
            entry["yieldable"] = True
        if wait is not None:
            # When this client gives up (plan(): a head that would give up before its start holds nobody back).
            entry["until"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + wait))
        own = order_settings(directory)["yield_after"]
        if own != order_settings(directory, environment=False)["yield_after"]:
            entry["yield_after"] = own  # this client asks later or never (SLOTFATHER_YIELD_AFTER); others' looks read it
        write(path, entry)
    lease = Lease(count, path, yieldable=yieldable)
    deadline = None if wait is None else time.monotonic() + wait
    # A terminated waiter leaves the queue at once rather than at the next reap.
    main_thread = threading.current_thread() is threading.main_thread()
    previous_term = signal.signal(signal.SIGTERM, terminate) if main_thread else None
    try:
        said, interval, look = None, poll, 0.0
        while True:
            if time.monotonic() >= look:
                # A full look runs ps over the machine under the queue lock. While the reason to wait stays the same,
                # each pause is half as long again, up to poll_max: a release grants at once, so only reaping a
                # crashed holder and memory recovering wait for a look.
                with locked(directory):
                    waiting = grant(directory, processes())
                interval = poll if waiting != said else min(interval * 1.5, poll_max)
                look = time.monotonic() + interval
            try:
                current = json.loads(path.read_text())  # written whole by rename: no lock needed
                state = current["state"]
            except (OSError, ValueError, KeyError, TypeError):
                raise SlotError("the lease vanished from the queue") from None
            if state == "held":
                if isinstance(current.get("count"), int) and current["count"] >= 1:
                    count = lease.count = current["count"]  # the capacity changed while it waited (plan())
                if said:
                    print(f"slot: granted {count} slot(s) to {label}", file=out, flush=True)
                return lease
            if deadline is not None and time.monotonic() >= deadline:
                raise SlotTimeout(f"no {count} slot(s) within {wait:g} s: {waiting or 'earlier requests first'}")
            if waiting != said:
                print(f"slot: {label} waits for {count} slot(s): {waiting or 'earlier requests first'}",
                      file=out, flush=True)
                for line in status_lines(directory):
                    print(f"  {line}", file=out, flush=True)
                if note and said is None:
                    print(f"slot: {note}", file=out, flush=True)
                said = waiting
            pause = min(poll, max(0.0, look - time.monotonic()))
            time.sleep(pause if deadline is None else max(0.0, min(pause, deadline - time.monotonic())))
    except BaseException:
        lease.release()
        raise
    finally:
        if previous_term is not None:
            signal.signal(signal.SIGTERM, previous_term)


def terminate(signum, _frame):
    raise SystemExit(128 + signum)


def run(count: int | str, label: str, argv: list[str], wait: float | None = None, meta: dict | None = None,
        yieldable: bool = False) -> int:
    """Run argv under a lease of `count` slots; the command's exit status."""
    try:
        background = policy() == "background"
        lease = acquire(count, label, " ".join(argv), wait=wait, note=ALL_NOTE if count == "all" else "", meta=meta,
                        yieldable=yieldable)
    except SlotTimeout as error:
        print(f"slot: {label}: {error}", file=sys.stderr)
        return TIMED_OUT
    except KeyboardInterrupt:
        return 130
    except SystemExit as stop:
        return int(stop.code or 1)
    with lease:
        if background:
            prefix = ["/usr/sbin/taskpolicy", "-b", "/usr/bin/nice", "-n", "10"] if os.access(
                "/usr/sbin/taskpolicy", os.X_OK) else ["/usr/bin/nice", "-n", "10"]
            argv = prefix + argv
        try:
            child = subprocess.Popen(argv, env={**os.environ, **lease.environment()})
        except OSError as error:
            print(f"slot: {error}", file=sys.stderr)
            return 127
        began = time.monotonic()
        watch = None
        if lease.path is not None and not lease.inherited:
            marker = str(lease.path)
            watch = Watch(TreeUsage(child.pid, time.time() - 1, lambda pids: carrying(pids, marker)),
                          lease.path.parent.parent)
            with contextlib.suppress(RuntimeError):
                watch.start()
        reaped = []

        def forward(signum, _frame):
            # os.kill rather than child.send_signal, which polls and could reap the child before wait4 sees it;
            # until wait4 returns the child (a zombie at worst) keeps its pid.
            if not reaped:
                with contextlib.suppress(ProcessLookupError):
                    os.kill(child.pid, signum)
        # The terminal sends SIGINT to the child's process group itself; the lease outlives the child.
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        for signum in (signal.SIGTERM, signal.SIGHUP):
            signal.signal(signum, forward)
        try:
            _, raw, rusage = os.wait4(child.pid, 0)  # the rusage holds every descendant reaped inside the tree
            status = os.waitstatus_to_exitcode(raw)
        except ChildProcessError:
            status, rusage = child.wait(), None
        reaped.append(True)
        if watch is not None:
            watch.usage.root_gone = True  # before any later look: the pid may be reused from now on
        child.returncode = status
        if watch is not None and watch.is_alive():
            lease.usage = watch.finish(rusage, time.monotonic() - began)
        lease.status = 128 - status if status < 0 else status
    return lease.status


# Command line

def companion(name: str, argv: list[str], title: str) -> int:
    """Runs slotfather-<name> from beside this file with this interpreter: the dashboard's and the statistics' code
    never loads with the queue's, and a fault in it cannot reach admission."""
    path = Path(__file__).resolve().with_name(f"slotfather-{name}")
    if not path.is_file():
        raise SlotError(f"{title} is not installed beside slotfather: {path}")
    os.execv(sys.executable, [sys.executable, str(path), *argv])
    return 0  # not reached


def dashboard(argv: list[str]) -> int:
    return companion("dashboard", argv, "the dashboard")



USAGE = ("usage: slotfather                     (in a terminal: the live dashboard)\n"
         "       slotfather run [-n N|all] [--label L] [--meta KEY=VALUE]... [--class interactive|normal|batch]\n"
         "                      [--yieldable] [--wait SECONDS] [--] COMMAND...      (inside a lease: slotfather yield)\n"
         "       slotfather status [--json [--pid PID]] | history [N] | available [--label L] [-- COMMAND...]\n"
         "       slotfather advise [--max N] [--exclusive] [--label L] [-- COMMAND...]\n"
         "       slotfather order [backfill|window] [--safety X] [--limit S] [--fallback S] [--overrun X]\n"
         "                        [--interactive S] [--batch S] [--yield-after S] | reset\n"
         "       slotfather stats [--since WHEN] [--label GLOB] [--by both|label|kind] [--top N] [--json]\n"
         "       slotfather slots [N|memory GIB|lower GIB|reset]\n"
         "       slotfather sweep [--live [--dev-servers]] [--json] [--quiet] [--pid PID]... | sweep config [KEY VALUE]...\n"
         "                        | sweep --plist [--live [--dev-servers]] [--interval SECONDS]\n"
         "       slotfather dashboard [--interval SECONDS] | dashboard --once [--width N] [--height N] [--color]")


def parse_count(value: str) -> int:
    if value == "all":
        return total()
    if not value.isdigit() or int(value) < 1:
        raise SlotError(f"-n takes a positive count or all, not {value!r}")
    return int(value)


def run_command(argv: list[str]) -> int:
    count, label, wait, pairs, yieldable = 1, os.path.basename(os.getcwd()), None, [], False
    while argv:
        if argv[0] in ("-n", "--slots") and len(argv) > 1:
            count, argv = ("all" if argv[1] == "all" else parse_count(argv[1])), argv[2:]
        elif argv[0] in ("-l", "--label") and len(argv) > 1:
            label, argv = argv[1], argv[2:]
        elif argv[0] == "--meta" and len(argv) > 1:
            pairs, argv = pairs + [argv[1]], argv[2:]
        elif argv[0] == "--class" and len(argv) > 1:
            if argv[1] not in CLASSES:
                raise SlotError(f"--class takes {', '.join(CLASSES)}, not {argv[1]!r}")
            pairs, argv = pairs + [f"class={argv[1]}"], argv[2:]
        elif argv[0] == "--yieldable":
            yieldable, argv = True, argv[1:]
        elif argv[0] == "--wait" and len(argv) > 1:
            try:
                wait = float(argv[1])
            except ValueError:
                raise SlotError(f"--wait takes seconds, not {argv[1]!r}") from None
            argv = argv[2:]
        elif argv[0] == "--":
            argv = argv[1:]
            break
        elif argv[0].startswith("-"):
            raise SlotError(f"unknown option {argv[0]}")
        else:
            break
    if not argv:
        raise SlotError("no command to run")
    return run(count, label, argv, wait, parse_meta(pairs), yieldable)


def request_options(argv: list[str], what: str, flags: dict) -> tuple[dict, str, str]:
    """`flags` (option -> takes a value) and then `[--label L] [-- COMMAND...]`: (options, label, command). The
    label defaults to the directory's name, as for run."""
    found, label, command = {}, os.path.basename(os.getcwd()), ""
    while argv:
        if argv[0] == "--":
            command = " ".join(argv[1:])
            break
        if argv[0] in ("-l", "--label") and len(argv) > 1:
            label, argv = argv[1], argv[2:]
        elif argv[0] in flags and (not flags[argv[0]] or len(argv) > 1):
            found[argv[0]] = argv[1] if flags[argv[0]] else True
            argv = argv[2:] if flags[argv[0]] else argv[1:]
        else:
            raise SlotError(f"unknown {what} option {argv[0]}")
    return found, label, command


def yield_command(argv: list[str]) -> int:
    """`slotfather yield`, from inside a yieldable lease between two steps: yields if asked and returns once the
    lease is held again; returns at once when nothing asked. Exit 0 either way."""
    if argv:
        raise SlotError("yield takes no arguments")
    require_own(state_dir(), "yield")
    found = inherited_lease(processes())
    if found is None or found[0].parent.parent != state_dir():
        raise SlotError("yield runs inside a lease of this queue (SLOTFATHER_LEASE, or a holder among its ancestors)")
    if not yield_lease(found[0]):
        print("slot: no yield requested", file=sys.stderr)
    return 0


def status_command(argv: list[str]) -> int:
    """`status --json [--pid PID]`."""
    pid = None
    if argv[:1] == ["--pid"] and len(argv) == 2 and argv[1].isdigit():
        pid = int(argv[1])
    elif argv:
        raise SlotError("status takes --json and then optionally --pid PID")
    print(json.dumps(status_json(pid=pid), sort_keys=True))
    return 0


def advise_command(argv: list[str]) -> int:
    found, label, command = request_options(argv, "advise", {"--max": True, "--exclusive": False})
    maximum = parse_count(found["--max"]) if "--max" in found else None
    print(json.dumps(advise(maximum, "--exclusive" in found, label=label, command=command), sort_keys=True))
    return 0


def available_command(argv: list[str]) -> int:
    _, label, command = request_options(argv, "available", {})
    print(available(label=label, command=command))
    return 0


def order_line(found: dict) -> str:
    return (f"{found['order']}: safety {found['safety']:g}, limit {found['limit']:g} s, fallback "
            f"{found['fallback']:g} s, overrun {found['overrun']:g}; interactive {found['interactive']:g} s ahead, "
            f"batch {found['batch']:g} s behind, yield after {found['yield_after']:g} s "
            f"({'saved' if found['saved'] else 'default'})")


def order_command(argv: list[str]) -> int:
    """`slotfather order [backfill|window] [--safety X] [--limit S] [--fallback S] [--overrun X] | reset`."""
    directory = state_dir()
    changes, reset = {}, False
    while argv:
        word = argv.pop(0)
        if word in QUEUE_ORDERS:
            changes["order"] = word
        elif word == "reset" and not changes:
            reset = True
        elif word.startswith("--") and word[2:].replace("-", "_") in ORDER_KNOBS and argv:
            try:
                changes[word[2:].replace("-", "_")] = float(argv.pop(0))
            except ValueError:
                raise SlotError(f"{word} takes a number") from None
        else:
            raise SlotError(f"order takes backfill or window, --safety, --limit, --fallback, --overrun, "
                            f"--interactive, --batch, --yield-after, or reset; not {word!r}")
    if reset and changes:
        raise SlotError("order reset takes nothing else")
    if changes or reset:
        require_own(directory, "an order change")
        with locked(directory):
            saved = dict(ORDER_DEFAULTS)  # what is saved, without this client's environment
            with contextlib.suppress(OSError, ValueError, TypeError, AttributeError):
                saved.update(checked_order(json.loads((directory / "order.json").read_text())))
            values = None if reset else {**saved, **changes}
            try:
                save_order(values, directory)
            except ValueError as error:
                raise SlotError(str(error)) from None
            except OSError as error:
                raise SlotError(f"cannot save the order: {error}") from None
    saved = order_settings(directory, environment=False)
    moved = [k for k in ORDER_DEFAULTS if k not in ORDER_BASE and saved[k] != ORDER_DEFAULTS[k]]
    if (changes or reset) and moved:
        print(f"slotfather: note: order.json now holds {', '.join(moved)}, which slotfather 3e3a621 and older do not "
              f"know: their looks fall back to the window order until they are updated", file=sys.stderr)
    print(order_line(order_settings(directory)))
    return 0


def slots_value(argv: list[str]) -> dict | None:
    """What `slots` saves: {"slots": N}, {"mode", "gib_per_slot", "slots"} or None for reset. The memory modes also
    save the count they give now as "slots", which slotfather 0af7546 and older read alone."""
    if len(argv) == 1 and argv[0] == "reset":
        return None
    if len(argv) == 1 and argv[0].isascii() and argv[0].isdigit() and int(argv[0]) >= 1:
        return {"slots": int(argv[0])}
    if len(argv) == 2 and argv[0] in CAPACITY_MODES:
        try:
            per_slot = float(argv[1])
        except ValueError:
            per_slot = 0.0
        if math.isfinite(per_slot) and per_slot > 0:
            per_slot = int(per_slot) if per_slot.is_integer() else per_slot
            # The cgroup is the saver's (SLOTFATHER_CGROUP, or its outermost limited one), not the one saved before.
            group = (setting("CGROUP") or DEFAULT_CGROUP or limited_cgroup()) if linux() else None
            if linux() and cgroup_limit(group) is None:
                print("slotfather: note: no cgroup with a memory limit here or in SLOTFATHER_CGROUP: the count "
                      "follows MemTotal, which a VM's balloon moves and which differs from what clients inside a "
                      "limited cgroup see; name the cgroup the leases share (SLOTFATHER_CGROUP=/a.slice/b.slice, "
                      "or install.py --cgroup)", file=sys.stderr)
            by_memory = memory_slots(memory_gib(group or ""), per_slot)
            if by_memory is None:
                raise SlotError("the machine's memory is unknown here; save a count instead (slotfather slots N)")
            cpu = max(1, cores() // CORES_PER_SLOT)
            found = {"slots": by_memory if argv[0] == "memory" else min(cpu, by_memory), "mode": argv[0],
                     "gib_per_slot": per_slot}
            if cgroup_limit(group) is not None:
                found["cgroup"] = group
            return found
    raise SlotError("slots takes a positive integer, memory GIB or lower GIB (GiB per slot), or reset")


def slots_command(argv: list[str]) -> int:
    directory = state_dir()
    if argv:
        require_own(directory, "a capacity change")
    value = slots_value(argv) if argv else None
    with locked(directory):
        if argv:
            table = processes()
            live = reap(directory, table)
            legacy_live = any(alive(entry, table) for old in legacy_dirs() for _, entry in entries(old))
            if live or legacy_live:
                raise SlotError("queue is busy; capacity can change only after every holder and waiter leaves")
            path = directory / "capacity.json"
            try:
                if value is None:
                    path.unlink(missing_ok=True)
                else:
                    write(path, value)
            except OSError as error:
                raise SlotError(f"cannot save capacity: {error}") from None
        found = capacity_basis()
    print(capacity_text(found))
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    command, rest = (argv[0], argv[1:]) if argv else ("", [])
    # A person typing just `slotfather` wants to see the queue; a script or agent without a terminal gets the usage.
    if not argv and sys.stdin.isatty() and sys.stdout.isatty():
        command = "dashboard"
    try:
        if command == "run":
            return run_command(rest)
        if command == "slots":
            return slots_command(rest)
        if command == "status" and not rest:
            print("\n".join(status_lines()))
            return 0
        if command == "status" and rest[:1] == ["--json"]:
            return status_command(rest[1:])
        if command == "yield":
            return yield_command(rest)
        if command == "history" and (not rest or (len(rest) == 1 and rest[0].isdigit())):
            print("\n".join(history_lines(int(rest[0]) if rest else 20)))
            return 0
        if command == "available":
            return available_command(rest)
        if command == "order":
            return order_command(rest)
        if command == "advise":
            return advise_command(rest)
        if command == "dashboard":
            return dashboard(rest)
        if command == "stats":
            return companion("stats", rest, "slotfather-stats")
        if command == "sweep":
            return companion("sweep", rest, "slotfather-sweep")
        if command in ("-h", "--help", "help"):
            print(__doc__)
            return 0
    except SlotError as error:
        print(f"slotfather: {error}\n{USAGE}", file=sys.stderr)
        return 2
    print(USAGE, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
